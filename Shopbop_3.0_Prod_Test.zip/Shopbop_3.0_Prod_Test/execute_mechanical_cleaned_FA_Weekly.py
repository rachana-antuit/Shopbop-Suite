import re

from playwright.sync_api import Page, expect





TARGET_YAML_FILE = r"C:\Users\YG9387\Desktop\agentic-qa-orchestrator-main\agentic-qa-orchestrator-main\UI\workspaces\Shopbop_3.0\FA_Weekly_KB.yaml"
__PROJECT_OUTPUT_DIR__ = r"C:\Users\YG9387\Desktop\agentic-qa-orchestrator-main\agentic-qa-orchestrator-main\UI\outputs\Shopbop_3.0"

import os
import sys
import time
import yaml
import atexit
import contextlib
from datetime import datetime
import json

# --- Execution Tracking & Reporting ---
_successful_actions = []
_failed_actions = []

# 🔴 DYNAMIC DIRECTORY FOR EVERY RUN
RUN_TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

# Route directly to the absolute UI/outputs/ProjectName/
IMAGE_DIR = os.path.join(__PROJECT_OUTPUT_DIR__, "Mechanical_Images", f"Run_{RUN_TIMESTAMP}")
os.makedirs(IMAGE_DIR, exist_ok=True)

def _generate_execution_report():
    report_dir = os.path.join(__PROJECT_OUTPUT_DIR__, "Execution_Reports")
    os.makedirs(report_dir, exist_ok=True)
    report_path = os.path.join(report_dir, f"Mechanical_Execution_{RUN_TIMESTAMP}.txt")
    
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"Mechanical Execution Report\n")
        f.write("="*80 + "\n\n")
        f.write(f"Total Successful Actions: {len(_successful_actions)}\n")
        f.write(f"Total Failed/Healed Actions: {len(_failed_actions)}\n\n")
        
        f.write("--- ❌ FAILED ACTIONS (Required Healing/Manual) ---\n")
        if _failed_actions:
            for fa in _failed_actions: f.write(f"- {fa}\n")
        else:
            f.write("None! 100% of actions succeeded automatically.\n")
            
        f.write("\n--- ✅ SUCCESSFUL ACTIONS ---\n")
        for sa in _successful_actions: f.write(f"- {sa}\n")
            
    print(f"\n📊 Execution Report saved to: {report_path}\n")

atexit.register(_generate_execution_report)

# --- TELEMETRY & NETWORK TRACKING ---
captured_graphql_apis = []
active_api_calls = 0
IGNORED_ENDPOINTS = ["analytics", "telemetry", "log", "metrics", "heartbeat", "beacon", "socket", "wss", "live", "signalr"]

def handle_request(request):
    global active_api_calls
    if request.resource_type in ["fetch", "xhr"]:
        if not any(ignored in request.url.lower() for ignored in IGNORED_ENDPOINTS):
            active_api_calls += 1

def handle_request_done(request):
    global active_api_calls
    if request.resource_type in ["fetch", "xhr"]:
        if not any(ignored in request.url.lower() for ignored in IGNORED_ENDPOINTS):
            active_api_calls = max(0, active_api_calls - 1)

def get_composite_key(req_data):
    op_name = req_data.get("operationName", "unknown_op")
    try:
        dim_levels = req_data.get("variables", {}).get("query", {}).get("dimensionLevels")
        if dim_levels:
            dim_str = "-".join(str(d) for d in dim_levels) if isinstance(dim_levels, list) else str(dim_levels)
            return f"{op_name}_[{dim_str}]"
    except: pass
    return op_name

def handle_response(response):
    try:
        if response.request.method == "POST":
            post_text = response.request.post_data
            if post_text and '"operationName"' in post_text:
                req_data = json.loads(post_text)
                keys = []
                if isinstance(req_data, dict) and "operationName" in req_data:
                    keys.append((get_composite_key(req_data), req_data))
                elif isinstance(req_data, list):
                    for item in req_data:
                        if isinstance(item, dict) and "operationName" in item:
                            keys.append((get_composite_key(item), item))
                if keys:
                    try:
                        resp_json = response.json()
                        for k, req in keys:
                            captured_graphql_apis.append({
                                "api_key": k,
                                "request": req,
                                "response": resp_json
                            })
                    except: pass
    except: pass

# --- STABILITY ENGINE ---
WAIT_FOR_STABILITY_JS = '''
() => new Promise(resolve => {
    let checkCount = 0;
    const check = () => {
        checkCount++;
        const loaders = document.querySelectorAll('.ag-overlay-loading-wrapper, .spinner, .loading, [aria-busy="true"], .skeleton');
        let isVisible = false;
        for (let i = 0; i < loaders.length; i++) {
            const l = loaders[i];
            const style = window.getComputedStyle(l);
            if (l.offsetWidth > 0 && l.offsetHeight > 0 && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
                isVisible = true; break;
            }
        }
        if (isVisible && checkCount < 100) { setTimeout(check, 100); return; }
        resolve();
    };
    check();
})
'''

def wait_for_stability(page):
    global active_api_calls
    page.wait_for_timeout(50)
    wait_cycles = 0
    # 🔴 CAP NETWORK WAIT AT 1 SECOND (10 cycles * 100ms) to prevent hanging
    while active_api_calls > 0 and wait_cycles < 10: 
        page.wait_for_timeout(100)
        wait_cycles += 1
    try: page.evaluate(WAIT_FOR_STABILITY_JS)
    except: pass
    page.wait_for_timeout(100)

# --- WIDGETS ---
DRAW_CROSSHAIR_JS = '''
([x, y]) => {
    const div = document.createElement('div'); div.id = 'agent-intent-crosshair';
    div.style.cssText = `position:fixed; left:${x-25}px; top:${y-25}px; width:50px; height:50px; border:4px solid #00FF00; border-radius:50%; z-index:2147483647; pointer-events:none; box-shadow:0 0 15px #00FF00;`;
    const dot = document.createElement('div');
    dot.style.cssText = 'position:absolute; left:21px; top:21px; width:8px; height:8px; background-color:#FF0000; border-radius:50%;';
    div.appendChild(dot); document.body.appendChild(div);
}
'''

REMOVE_CROSSHAIR_JS = "() => { const e = document.getElementById('agent-intent-crosshair'); if(e) e.remove(); }"

MANUAL_CAPTURE_JS = '''
() => new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483647; cursor:crosshair; background:rgba(255,0,0,0.15);';
    const msg = document.createElement('div');
    msg.innerText = "🎯 TARGET MODE: Click the correct element on the screen to auto-heal";
    msg.style.cssText = 'position:absolute; top:20px; left:50%; transform:translateX(-50%); background:black; color:white; padding:12px 24px; font-size:18px; font-weight:bold; border-radius:8px; pointer-events:none; box-shadow: 0 4px 10px rgba(0,0,0,0.5);';
    overlay.appendChild(msg); document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation(); overlay.remove(); resolve({x: e.clientX, y: e.clientY});
    }, {capture: true, once: true});
})
'''

# --- Python Helper Functions ---
@contextlib.contextmanager
def safe_download(page, timeout_ms=30000):
    class DummyEvent:
        @property
        def value(self): return None
    try:
        with page.expect_download(timeout=timeout_ms) as d: yield d
        _successful_actions.append("Download action completed")
    except Exception as e:
        _failed_actions.append("Download action failed/timed out")
        yield DummyEvent()

def update_yaml_knowledge_base(step_id, healed_coords=None):
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id and healed_coords:
                    s['healed_coords'] = healed_coords
                    s['execution_mode'] = 'HEALED_COORDINATES'
        with open(TARGET_YAML_FILE, 'w', encoding='utf-8') as f: yaml.dump(kb, f, default_flow_style=False, sort_keys=False)
    except: pass

def check_for_healed_coords(step_id):
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id and 'healed_coords' in s: return s['healed_coords']
    except: pass
    return None

def safe_action(page, locator, action_name, step_id, before_path, intent_path, after_path, *args, **kwargs):
    print(f"\n▶ Step {step_id}: {action_name}")
    
    # 🔴 DETECT RIGHT CLICK
    is_right_click = kwargs.get('button') == 'right'
    mouse_click_btn = 'right' if is_right_click else 'left'
    
    # MAP PATHS
    before_path = os.path.join(IMAGE_DIR, os.path.basename(before_path))
    intent_path = os.path.join(IMAGE_DIR, os.path.basename(intent_path))
    after_path = os.path.join(IMAGE_DIR, os.path.basename(after_path))
    
    page.wait_for_timeout(50)
    page.screenshot(path=before_path)
    print(f"  └── 📸 Captured Before: {before_path}")
    
    # 🔴 ADVANCED ANGULAR DOMAIN EXTRACTION
    parent_context = "page_level"
    try:
        # Prevent 30s timeout by ensuring element exists before evaluating
        if locator.count() > 0:
            js_find_parent = '''el => {
                let current = el;
                let gridId = null;
                while (current && current !== document.body && current !== document.documentElement) {
                    if (current.hasAttribute('grid-id')) gridId = current.getAttribute('grid-id');
                    if (current.hasAttribute('data-testid')) return `testid:${current.getAttribute('data-testid')}`;
                    
                    if (current.tagName && current.tagName.includes('-') && !current.tagName.toLowerCase().startsWith('ag-')) {
                        let ctx = current.tagName.toLowerCase();
                        if (gridId) ctx += `_gridId-${gridId}`;
                        return ctx;
                    }
                    
                    if (current.id && current.id !== 'undefined' && !current.id.startsWith('ag-') && !current.id.startsWith('cdk-')) {
                        return `id:${current.id}`;
                    }
                    current = current.parentElement;
                }
                if (gridId) return `ag_grid_id_${gridId}`;
                const rect = el.getBoundingClientRect();
                if (rect) {
                    const qX = Math.floor(rect.left / (window.innerWidth / 2));
                    const qY = Math.floor(rect.top / (window.innerHeight / 2));
                    return `screen_quadrant_${qX}_${qY}`;
                }
                return 'page_level';
            }'''
            extracted_context = locator.first.evaluate(js_find_parent)
            if extracted_context:
                parent_context = extracted_context
                print(f"  └── 🧭 Component Scope: {parent_context}")
    except:
        pass
    
    healed = check_for_healed_coords(step_id)
    target_x, target_y = None, None
    if healed: 
        target_x, target_y = healed['x'], healed['y']
    else:
        try:
            locator.scroll_into_view_if_needed(timeout=500)
            box = locator.bounding_box()
            if box:
                target_x = box['x'] + (box['width'] / 2)
                target_y = box['y'] + (box['height'] / 2)
        except: pass

    if target_x is not None and target_y is not None:
        try:
            page.evaluate(DRAW_CROSSHAIR_JS, [target_x, target_y])
            page.wait_for_timeout(50) 
            page.screenshot(path=intent_path)
            print(f"  └── 🎯 Captured Intent: {intent_path}")
            page.evaluate(REMOVE_CROSSHAIR_JS)
        except: pass

    fallback_success = False
    
    # --- HEALED FALLBACK ROUTING ---
    if healed and action_name in ['click', 'dblclick', 'hover']:
        try:
            if action_name == 'click': page.mouse.click(target_x, target_y, button=mouse_click_btn)
            elif action_name == 'dblclick': page.mouse.dblclick(target_x, target_y, button=mouse_click_btn)
            elif action_name == 'hover': page.mouse.move(target_x, target_y)
            fallback_success = True
            print("  └── ✅ Healed Coordinate action executed.")
        except: pass
    else:
        try:
            if 'timeout' not in kwargs: kwargs['timeout'] = 3000
            getattr(locator, action_name)(*args, **kwargs)
            fallback_success = True
            print("  └── ✅ Native action succeeded.")
        except Exception as e:
            error_msg = str(e)
            print(f"  └── ⚠️ Native action failed: {error_msg.splitlines()[0][:80]}...")
            print("  └── Initiating Autonomous Fallbacks...")
            
            if "strict mode violation" in error_msg.lower() and not fallback_success:
                try: getattr(locator.first, action_name)(*args, **kwargs); fallback_success = True; print("  └── 🛠️ F1 Succeeded.")
                except: pass
                
            if not fallback_success and action_name in ['click', 'dblclick', 'check', 'uncheck', 'hover']:
                try: forced = kwargs.copy(); forced['force'] = True; getattr(locator, action_name)(*args, **forced); fallback_success = True; print("  └── 🛠️ F2 Succeeded.")
                except: pass
                
            if not fallback_success and action_name in ['click', 'check', 'uncheck']:
                try: 
                    if action_name == 'click': 
                        if is_right_click: locator.evaluate("el => el.dispatchEvent(new MouseEvent('contextmenu', {bubbles: true, cancelable: true, view: window, button: 2}))")
                        else: locator.evaluate("el => el.click()")
                    elif action_name == 'check': locator.evaluate("el => { el.checked = true; el.dispatchEvent(new Event('change')); }")
                    elif action_name == 'uncheck': locator.evaluate("el => { el.checked = false; el.dispatchEvent(new Event('change')); }")
                    fallback_success = True; print("  └── 🛠️ F3 Succeeded.")
                except: pass
                
            if not fallback_success and target_x is not None and action_name in ['click', 'dblclick', 'hover']:
                try: 
                    if action_name == 'click': page.mouse.click(target_x, target_y, button=mouse_click_btn)
                    elif action_name == 'hover': page.mouse.move(target_x, target_y)
                    fallback_success = True; print("  └── 🛠️ F4 Succeeded.")
                except: pass
                
            if not fallback_success and "Timeout" in error_msg:
                try: 
                    page.evaluate("() => { document.querySelectorAll('.ag-body-viewport').forEach(v => { v.scrollTop+=300; setTimeout(()=>v.scrollTop-=300, 150); }); }")
                    time.sleep(0.5); getattr(locator, action_name)(*args, **kwargs); fallback_success = True; print("  └── 🛠️ F6 Succeeded.")
                except: pass

    # --- MANUAL MODE OVERRIDE ---
    if not fallback_success:
        print(f"  └── 🛑 ALL FALLBACKS FAILED. INJECTING TARGET MODE...")
        _failed_actions.append(f"Step {step_id}: {action_name}")
        coords = page.evaluate(MANUAL_CAPTURE_JS)
        if coords:
            update_yaml_knowledge_base(step_id, healed_coords=coords)
            try:
                page.evaluate(DRAW_CROSSHAIR_JS, [coords['x'], coords['y']])
                page.wait_for_timeout(100)
                page.screenshot(path=intent_path)
                page.evaluate(REMOVE_CROSSHAIR_JS)
                page.mouse.click(coords['x'], coords['y'], button=mouse_click_btn)
                print("  └── ✅ Manual click executed and HEALED for future runs.")
            except: pass
    else:
        _successful_actions.append(f"Step {step_id}: {action_name}")

    wait_for_stability(page)
    page.screenshot(path=after_path)
    print(f"  └── 📸 Captured After:  {after_path}")
    
    # 🔴 RECORD NEW PATHS AND COMPONENT CONTEXT
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id:
                    s['baseline_images']['before'] = before_path
                    s['baseline_images']['intent'] = intent_path
                    s['baseline_images']['after'] = after_path
                    s['parent_context'] = parent_context
        with open(TARGET_YAML_FILE, 'w', encoding='utf-8') as f: yaml.dump(kb, f, default_flow_style=False, sort_keys=False)
    except: pass

def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    page.on('response', handle_response)
    page.on('request', handle_request)
    page.on('requestfinished', handle_request_done)
    page.on('requestfailed', handle_request_done)
    try: page.goto("https://shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=2", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print('\n✅ Initializing Stability Engine...')
    wait_for_stability(page)
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_1', 'baselines/step_1_1_before.png', 'baselines/step_1_1_intent.png', 'baselines/step_1_1_after.png')

    safe_action(page, page.get_by_text("All", exact=True).nth(2), 'click', '1_2', 'baselines/step_1_2_before.png', 'baselines/step_1_2_intent.png', 'baselines/step_1_2_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_3', 'baselines/step_1_3_before.png', 'baselines/step_1_3_intent.png', 'baselines/step_1_3_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_4', 'baselines/step_1_4_before.png', 'baselines/step_1_4_intent.png', 'baselines/step_1_4_after.png')

    safe_action(page, page.get_by_text("Demand Plan").nth(2), 'click', '1_5', 'baselines/step_1_5_before.png', 'baselines/step_1_5_intent.png', 'baselines/step_1_5_after.png')

    safe_action(page, page.get_by_text("Base Override").nth(1), 'click', '1_6', 'baselines/step_1_6_before.png', 'baselines/step_1_6_intent.png', 'baselines/step_1_6_after.png')

    safe_action(page, page.get_by_text("Promo Override").nth(1), 'click', '1_7', 'baselines/step_1_7_before.png', 'baselines/step_1_7_intent.png', 'baselines/step_1_7_after.png')

    safe_action(page, page.get_by_text("AI Total Forecast").nth(3), 'click', '1_8', 'baselines/step_1_8_before.png', 'baselines/step_1_8_intent.png', 'baselines/step_1_8_after.png')

    safe_action(page, page.get_by_text("AI Base Forecast").nth(3), 'click', '1_9', 'baselines/step_1_9_before.png', 'baselines/step_1_9_intent.png', 'baselines/step_1_9_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_10', 'baselines/step_1_10_before.png', 'baselines/step_1_10_intent.png', 'baselines/step_1_10_after.png')

    safe_action(page, page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100"), 'click', '1_11', 'baselines/step_1_11_before.png', 'baselines/step_1_11_intent.png', 'baselines/step_1_11_after.png')

    safe_action(page, page.get_by_text("AI Promo Forecast").nth(3), 'click', '1_12', 'baselines/step_1_12_before.png', 'baselines/step_1_12_intent.png', 'baselines/step_1_12_after.png')

    safe_action(page, page.get_by_text("LY Actual Demand").nth(4), 'click', '1_13', 'baselines/step_1_13_before.png', 'baselines/step_1_13_intent.png', 'baselines/step_1_13_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_14', 'baselines/step_1_14_before.png', 'baselines/step_1_14_intent.png', 'baselines/step_1_14_after.png')

    safe_action(page, page.get_by_text("Forecast/Actual Demand, YOY").first, 'click', '1_15', 'baselines/step_1_15_before.png', 'baselines/step_1_15_intent.png', 'baselines/step_1_15_after.png')

    safe_action(page, page.get_by_text("Forecast/Actual Demand").nth(3), 'click', '1_16', 'baselines/step_1_16_before.png', 'baselines/step_1_16_intent.png', 'baselines/step_1_16_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_17', 'baselines/step_1_17_before.png', 'baselines/step_1_17_intent.png', 'baselines/step_1_17_after.png')

    safe_action(page, page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100"), 'click', '1_18', 'baselines/step_1_18_before.png', 'baselines/step_1_18_intent.png', 'baselines/step_1_18_after.png')

    safe_action(page, page.locator(".overflow-auto > div:nth-child(12)"), 'click', '1_19', 'baselines/step_1_19_before.png', 'baselines/step_1_19_intent.png', 'baselines/step_1_19_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_20', 'baselines/step_1_20_before.png', 'baselines/step_1_20_intent.png', 'baselines/step_1_20_after.png')

    safe_action(page, page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100"), 'click', '1_21', 'baselines/step_1_21_before.png', 'baselines/step_1_21_intent.png', 'baselines/step_1_21_after.png')

    safe_action(page, page.get_by_text("Imputed Flag").nth(1), 'click', '1_22', 'baselines/step_1_22_before.png', 'baselines/step_1_22_intent.png', 'baselines/step_1_22_after.png')

    safe_action(page, page.get_by_text("YOY % Change").nth(1), 'click', '1_23', 'baselines/step_1_23_before.png', 'baselines/step_1_23_intent.png', 'baselines/step_1_23_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_24', 'baselines/step_1_24_before.png', 'baselines/step_1_24_intent.png', 'baselines/step_1_24_after.png')

    safe_action(page, page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100"), 'click', '1_25', 'baselines/step_1_25_before.png', 'baselines/step_1_25_intent.png', 'baselines/step_1_25_after.png')

    safe_action(page, page.get_by_text("Planner Flag").nth(1), 'click', '1_26', 'baselines/step_1_26_before.png', 'baselines/step_1_26_intent.png', 'baselines/step_1_26_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_27', 'baselines/step_1_27_before.png', 'baselines/step_1_27_intent.png', 'baselines/step_1_27_after.png')

    safe_action(page, page.get_by_text("None").nth(1), 'click', '1_28', 'baselines/step_1_28_before.png', 'baselines/step_1_28_intent.png', 'baselines/step_1_28_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_29', 'baselines/step_1_29_before.png', 'baselines/step_1_29_intent.png', 'baselines/step_1_29_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_30', 'baselines/step_1_30_before.png', 'baselines/step_1_30_intent.png', 'baselines/step_1_30_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_31', 'baselines/step_1_31_before.png', 'baselines/step_1_31_intent.png', 'baselines/step_1_31_after.png')

    safe_action(page, page.get_by_role("textbox", name="Filter Columns Input"), 'click', '1_32', 'baselines/step_1_32_before.png', 'baselines/step_1_32_intent.png', 'baselines/step_1_32_after.png')

    safe_action(page, page.get_by_role("textbox", name="Filter Columns Input"), 'fill', '1_33', 'baselines/step_1_33_before.png', 'baselines/step_1_33_intent.png', 'baselines/step_1_33_after.png', "2026-08")

    safe_action(page, page.get_by_role("textbox", name="Filter Columns Input"), 'press', '1_34', 'baselines/step_1_34_before.png', 'baselines/step_1_34_intent.png', 'baselines/step_1_34_after.png', "Enter")

    safe_action(page, page.get_by_text("-08-02 (32)"), 'click', '1_35', 'baselines/step_1_35_before.png', 'baselines/step_1_35_intent.png', 'baselines/step_1_35_after.png')

    safe_action(page, page.locator("div:nth-child(2) > .ag-column-select-column"), 'click', '1_36', 'baselines/step_1_36_before.png', 'baselines/step_1_36_intent.png', 'baselines/step_1_36_after.png')

    safe_action(page, page.get_by_text("-08-16 (34)"), 'click', '1_37', 'baselines/step_1_37_before.png', 'baselines/step_1_37_intent.png', 'baselines/step_1_37_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_38', 'baselines/step_1_38_before.png', 'baselines/step_1_38_intent.png', 'baselines/step_1_38_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_39', 'baselines/step_1_39_before.png', 'baselines/step_1_39_intent.png', 'baselines/step_1_39_after.png')

    safe_action(page, page.get_by_role("checkbox", name="Toggle All Columns Visibility"), 'uncheck', '1_40', 'baselines/step_1_40_before.png', 'baselines/step_1_40_intent.png', 'baselines/step_1_40_after.png')

    safe_action(page, page.get_by_text("Weekly Summary Product:ALEDM-"), 'click', '1_41', 'baselines/step_1_41_before.png', 'baselines/step_1_41_intent.png', 'baselines/step_1_41_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_42', 'baselines/step_1_42_before.png', 'baselines/step_1_42_intent.png', 'baselines/step_1_42_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_43', 'baselines/step_1_43_before.png', 'baselines/step_1_43_intent.png', 'baselines/step_1_43_after.png')

    safe_action(page, page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-header"), 'click', '1_44', 'baselines/step_1_44_before.png', 'baselines/step_1_44_intent.png', 'baselines/step_1_44_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_45', 'baselines/step_1_45_before.png', 'baselines/step_1_45_intent.png', 'baselines/step_1_45_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_46', 'baselines/step_1_46_before.png', 'baselines/step_1_46_intent.png', 'baselines/step_1_46_after.png')

    safe_action(page, page.get_by_role("checkbox", name="Toggle All Columns Visibility"), 'check', '1_47', 'baselines/step_1_47_before.png', 'baselines/step_1_47_intent.png', 'baselines/step_1_47_after.png')

    safe_action(page, page.get_by_role("textbox", name="Filter Columns Input"), 'click', '1_48', 'baselines/step_1_48_before.png', 'baselines/step_1_48_intent.png', 'baselines/step_1_48_after.png')

    safe_action(page, page.get_by_role("textbox", name="Filter Columns Input"), 'fill', '1_49', 'baselines/step_1_49_before.png', 'baselines/step_1_49_intent.png', 'baselines/step_1_49_after.png', "")

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_50', 'baselines/step_1_50_before.png', 'baselines/step_1_50_intent.png', 'baselines/step_1_50_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_51', 'baselines/step_1_51_before.png', 'baselines/step_1_51_intent.png', 'baselines/step_1_51_after.png')

    safe_action(page, page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-list > .ag-virtual-list-viewport > .ag-virtual-list-container > div > .ag-column-select-column > .ag-icon").first, 'click', '1_52', 'baselines/step_1_52_before.png', 'baselines/step_1_52_intent.png', 'baselines/step_1_52_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_53', 'baselines/step_1_53_before.png', 'baselines/step_1_53_intent.png', 'baselines/step_1_53_after.png')

    safe_action(page, page.locator(".display-grid-icons > div:nth-child(4) > div"), 'click', '1_54', 'baselines/step_1_54_before.png', 'baselines/step_1_54_intent.png', 'baselines/step_1_54_after.png')

    safe_action(page, page.get_by_text("-07-05 (28)"), 'click', '1_55', 'baselines/step_1_55_before.png', 'baselines/step_1_55_intent.png', 'baselines/step_1_55_after.png')

    safe_action(page, page.get_by_text("-07-19 (30)"), 'click', '1_56', 'baselines/step_1_56_before.png', 'baselines/step_1_56_intent.png', 'baselines/step_1_56_after.png')

    safe_action(page, page.get_by_text("-07-19 (30)"), 'click', '1_57', 'baselines/step_1_57_before.png', 'baselines/step_1_57_intent.png', 'baselines/step_1_57_after.png')

    safe_action(page, page.get_by_role("columnheader", name="-07-12 (29)"), 'click', '1_58', 'baselines/step_1_58_before.png', 'baselines/step_1_58_intent.png', 'baselines/step_1_58_after.png')

    safe_action(page, page.get_by_text("-07-19 (30)"), 'click', '1_59', 'baselines/step_1_59_before.png', 'baselines/step_1_59_intent.png', 'baselines/step_1_59_after.png')

    safe_action(page, page.get_by_text("-07-12 (29)"), 'click', '1_60', 'baselines/step_1_60_before.png', 'baselines/step_1_60_intent.png', 'baselines/step_1_60_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_61', 'baselines/step_1_61_before.png', 'baselines/step_1_61_intent.png', 'baselines/step_1_61_after.png')

    safe_action(page, page.get_by_role("treeitem", name="-06-21 (26) Column").get_by_label("Press SPACE to toggle"), 'click', '1_62', 'baselines/step_1_62_before.png', 'baselines/step_1_62_intent.png', 'baselines/step_1_62_after.png')

    safe_action(page, page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-list > .ag-virtual-list-viewport > .ag-virtual-list-container > div > .ag-column-select-column > .ag-icon").first, 'click', '1_63', 'baselines/step_1_63_before.png', 'baselines/step_1_63_intent.png', 'baselines/step_1_63_after.png')

    safe_action(page, page.get_by_role("checkbox", name="Press SPACE to toggle visibility (hidden)"), 'check', '1_64', 'baselines/step_1_64_before.png', 'baselines/step_1_64_intent.png', 'baselines/step_1_64_after.png')

    safe_action(page, page.locator("div:nth-child(2) > .ag-column-select-column"), 'click', '1_65', 'baselines/step_1_65_before.png', 'baselines/step_1_65_intent.png', 'baselines/step_1_65_after.png')

    safe_action(page, page.get_by_role("treeitem", name="-07-05 (28) Column").get_by_label("Press SPACE to toggle"), 'click', '1_66', 'baselines/step_1_66_before.png', 'baselines/step_1_66_intent.png', 'baselines/step_1_66_after.png')

    safe_action(page, page.locator("div:nth-child(4) > .ag-column-select-column"), 'click', '1_67', 'baselines/step_1_67_before.png', 'baselines/step_1_67_intent.png', 'baselines/step_1_67_after.png')

    safe_action(page, page.get_by_role("treeitem", name="-07-26 (31) Column").get_by_label("Press SPACE to toggle visibility (visible)"), 'click', '1_68', 'baselines/step_1_68_before.png', 'baselines/step_1_68_intent.png', 'baselines/step_1_68_after.png')

    safe_action(page, page.get_by_role("treeitem", name="-08-09 (33) Column").get_by_label("Press SPACE to toggle visibility (visible)"), 'uncheck', '1_69', 'baselines/step_1_69_before.png', 'baselines/step_1_69_intent.png', 'baselines/step_1_69_after.png')

    safe_action(page, page.get_by_role("treeitem", name="-08-16 (34) Column").get_by_label("Press SPACE to toggle visibility (visible)"), 'uncheck', '1_70', 'baselines/step_1_70_before.png', 'baselines/step_1_70_intent.png', 'baselines/step_1_70_after.png')

    safe_action(page, page.get_by_role("button", name="columns").nth(1), 'click', '1_71', 'baselines/step_1_71_before.png', 'baselines/step_1_71_intent.png', 'baselines/step_1_71_after.png')

    with safe_download(page) as download_info:

        safe_action(page, page.locator("div:nth-child(3) > .icon"), 'click', '1_72', 'baselines/step_1_72_before.png', 'baselines/step_1_72_intent.png', 'baselines/step_1_72_after.png')

    download = download_info.value

    safe_action(page, page.locator("div:nth-child(4) > div > .legend-font > .multiselect-dropdown > .pointer"), 'click', '1_73', 'baselines/step_1_73_before.png', 'baselines/step_1_73_intent.png', 'baselines/step_1_73_after.png')

    safe_action(page, page.get_by_text("Save Preference"), 'click', '1_74', 'baselines/step_1_74_before.png', 'baselines/step_1_74_intent.png', 'baselines/step_1_74_after.png')

    with safe_download(page) as download1_info:

        safe_action(page, page.locator("div:nth-child(3) > .icon > .icon-color-toolbar-active"), 'click', '1_75', 'baselines/step_1_75_before.png', 'baselines/step_1_75_intent.png', 'baselines/step_1_75_after.png')

    download1 = download1_info.value

    safe_action(page, page.locator("i").first, 'click', '1_76', 'baselines/step_1_76_before.png', 'baselines/step_1_76_intent.png', 'baselines/step_1_76_after.png')

    safe_action(page, page.locator("i").nth(2), 'click', '1_77', 'baselines/step_1_77_before.png', 'baselines/step_1_77_intent.png', 'baselines/step_1_77_after.png')

    safe_action(page, page.locator("i").nth(4), 'click', '1_78', 'baselines/step_1_78_before.png', 'baselines/step_1_78_intent.png', 'baselines/step_1_78_after.png')

    safe_action(page, page.locator(".ag-body-viewport.ag-layout-normal.ag-row-animation.ag-has-focus > .ag-center-cols-viewport"), 'click', '1_79', 'baselines/step_1_79_before.png', 'baselines/step_1_79_intent.png', 'baselines/step_1_79_after.png')

    safe_action(page, page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer"), 'click', '1_80', 'baselines/step_1_80_before.png', 'baselines/step_1_80_intent.png', 'baselines/step_1_80_after.png')

    safe_action(page, page.locator("#my-grid > .ag-root-wrapper > .ag-root-wrapper-body > .ag-root > .ag-header > .ag-header-viewport"), 'click', '1_81', 'baselines/step_1_81_before.png', 'baselines/step_1_81_intent.png', 'baselines/step_1_81_after.png')

    with safe_download(page) as download2_info:

        safe_action(page, page.locator("div:nth-child(3) > .icon > .icon-color-toolbar-active"), 'click', '1_82', 'baselines/step_1_82_before.png', 'baselines/step_1_82_intent.png', 'baselines/step_1_82_after.png')

    download2 = download2_info.value

    safe_action(page, page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer"), 'click', '1_83', 'baselines/step_1_83_before.png', 'baselines/step_1_83_intent.png', 'baselines/step_1_83_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Reset Preference$")).first, 'click', '1_84', 'baselines/step_1_84_before.png', 'baselines/step_1_84_intent.png', 'baselines/step_1_84_after.png')

    safe_action(page, page.locator("span").filter(has_text="Demand Plan").first, 'click', '1_85', 'baselines/step_1_85_before.png', 'baselines/step_1_85_intent.png', 'baselines/step_1_85_after.png')

    safe_action(page, page.locator("i").nth(1), 'click', '1_86', 'baselines/step_1_86_before.png', 'baselines/step_1_86_intent.png', 'baselines/step_1_86_after.png')

    safe_action(page, page.locator("i").nth(3), 'click', '1_87', 'baselines/step_1_87_before.png', 'baselines/step_1_87_intent.png', 'baselines/step_1_87_after.png')

    safe_action(page, page.locator("i").nth(1), 'click', '1_88', 'baselines/step_1_88_before.png', 'baselines/step_1_88_intent.png', 'baselines/step_1_88_after.png')

