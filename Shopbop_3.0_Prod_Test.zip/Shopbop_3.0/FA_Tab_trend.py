# RECORDED_URL: https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=2
import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.get_by_text("Weekly Trend Product:ALEDM-").click()
    page.locator("dp-line-bar-chart").get_by_text("ALEDM-Allen Edmonds").click()
    page.get_by_text("Demand Plan, Forecast/Actual").first.click()
    page.locator("dp-line-bar-chart").get_by_text("Base Override").click()
    page.locator(".overflow-auto > div:nth-child(6)").click()
    page.locator(".overflow-auto > div:nth-child(9)").click()
    page.get_by_text("All selected").first.click()
    page.locator("svg").get_by_text("Demand Plan").click()
    page.locator("path:nth-child(98)").click()
    page.locator("svg").get_by_text("Demand Plan").click()
    page.locator("svg").get_by_text("Forecast/Actual Demand").click()
    page.locator("svg").get_by_text("Forecast/Actual Demand").click()
    page.locator("svg").get_by_text("AI Total Forecast").click()
    page.locator("svg").get_by_text("AI Total Forecast").click()
    page.locator("svg").get_by_text("LY Actual Demand").click()
    page.locator("svg").get_by_text("LY Actual Demand").click()
    page.locator("path:nth-child(122)").click()
    page.locator("path:nth-child(108)").click()
    page.locator("svg").get_by_text("Base Override").click()
    page.locator("svg").get_by_text("Promo Override").click()
    page.locator("svg").get_by_text("Promo Override").click()
    page.locator("svg").get_by_text("AI Base Forecast").click()
    page.locator("svg").get_by_text("AI Base Forecast").click()
    page.locator("svg").get_by_text("YOY % Change").click()
    page.locator("svg").get_by_text("YOY % Change").click()
    page.locator("svg").get_by_text("AI Promo Forecast").click()
    page.locator("svg").get_by_text("AI Promo Forecast").click()
    page.locator(".title.d-flex.align-items-center.font-size-16.font-weight-bold.nunito.title-color > .grid-icons-container > esp-grid-icons-component > .display-grid-icons > div > div > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Save Preference").click()
    page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Reset Preference").click()
    page.locator("path:nth-child(106)").click()
    page.locator("path:nth-child(108)").click()
