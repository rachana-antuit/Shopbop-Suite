# RECORDED_URL: https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=3
import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator(".d-flex.dropdown-option").first.click()
    page.get_by_text("Demand Plan").nth(2).click()
    page.get_by_text("Weekly Summary Product:").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator("span").filter(has_text="Base Override").click()
    page.locator("span").filter(has_text="Promo Override").click()
    page.get_by_text("Demand Plan, Base Override,").first.click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.get_by_text("AI Total Forecast").nth(2).click()
    page.locator("span").filter(has_text="AI Base Forecast").click()
    page.get_by_text("Weekly Summary Product:").click()
    page.get_by_text("Weekly Summary Product:").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator("span").filter(has_text="AI Promo Forecast").click()
    page.locator("span").filter(has_text="Forecast/Actual Demand").click()
    page.locator("span").filter(has_text="LY Actual Demand").click()
    page.locator(".ag-row-odd.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0 > .ag-cell-value > .ag-cell-wrapper > .ag-group-expanded > .zeb-chevron-down").first.click()
    page.locator("i").nth(1).click()
    page.get_by_text("Demand Plan, Base Override,").first.click()
    page.locator("span").filter(has_text="YOY % Change").click()
    page.get_by_text("Planner Flag").click()
    page.locator("div:nth-child(12)").click()
    page.get_by_text("Imputed Flag").click()
    page.get_by_text("Weekly Summary Product:").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator("i").nth(5).click()
    page.locator("i").nth(5).click()
    page.locator(".ag-row-odd.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0.ag-row-position-absolute.ag-row-hover > div:nth-child(3)").click()
    page.locator("#my-grid").get_by_role("img").click()
    page.locator("#my-grid").get_by_role("img").dblclick()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator("i").nth(2).click()
    page.locator("i").nth(4).click()
    page.locator(".ag-row-even.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0.ag-row-group.ag-row-group-contracted.ag-row-position-absolute.ag-row-hover > .ag-cell-value > .ag-cell-wrapper > .ag-group-contracted > .zeb-chevron-right").click()
    page.locator("i").nth(1).click()
    page.locator("i").nth(1).click()
    page.locator("i").nth(4).click()
    page.get_by_role("button", name="columns").nth(2).click()
    page.get_by_role("textbox", name="Filter Columns Input").click()
    page.get_by_role("textbox", name="Filter Columns Input").fill("2024")
    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()
    page.locator("div:nth-child(5) > div > .legend-font > .multiselect-dropdown > .pointer").click()
    page.locator("div").filter(has_text=re.compile(r"^Save Preference$")).first.click()
    with page.expect_download() as download_info:
        page.locator("div:nth-child(3) > .icon > .icon-color-toolbar-active").click()
    download = download_info.value
    page.locator("div:nth-child(5) > .ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Reset Preference").click()
    page.locator("i").nth(1).click()
    page.locator(".ag-row-odd.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0 > .ag-cell-value > .ag-cell-wrapper > .ag-group-expanded > .zeb-chevron-down").first.click()
    page.get_by_text("All", exact=True).nth(1).click()
    page.get_by_role("button", name="columns").nth(2).click()
    page.get_by_role("textbox", name="Filter Columns Input").click()
    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()
    page.locator("div:nth-child(5) > div > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Save Preference").click()
    page.locator("div:nth-child(5) > .ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Weekly Summary Product:").click()
