import re

from playwright.sync_api import Page, expect





def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    try: page.goto("https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=2", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.get_by_text("All", exact=True).nth(2).click()

    page.get_by_text("Select All").click()

    page.get_by_text("Select All").click()

    page.get_by_text("Demand Plan").nth(2).click()

    page.get_by_text("Base Override").nth(1).click()

    page.get_by_text("Promo Override").nth(1).click()

    page.get_by_text("AI Total Forecast").nth(3).click()

    page.get_by_text("AI Base Forecast").nth(3).click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.get_by_text("AI Promo Forecast").nth(3).click()

    page.get_by_text("LY Actual Demand").nth(4).click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.get_by_text("Forecast/Actual Demand, YOY").first.click()

    page.get_by_text("Forecast/Actual Demand").nth(3).click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator(".overflow-auto > div:nth-child(12)").click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.get_by_text("Imputed Flag").nth(1).click()

    page.get_by_text("YOY % Change").nth(1).click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.get_by_text("Planner Flag").nth(1).click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.get_by_text("None").nth(1).click()

    page.get_by_text("Select All").click()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("2026-08")

    page.get_by_role("textbox", name="Filter Columns Input").press("Enter")

    page.get_by_text("-08-02 (32)").click()

    page.locator("div:nth-child(2) > .ag-column-select-column").click()

    page.get_by_text("-08-16 (34)").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()

    page.get_by_text("Weekly Summary Product:ALEDM-").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-header").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("")

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-list > .ag-virtual-list-viewport > .ag-virtual-list-container > div > .ag-column-select-column > .ag-icon").first.click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.locator(".display-grid-icons > div:nth-child(4) > div").click()

    page.get_by_text("-07-05 (28)").click()

    page.get_by_text("-07-19 (30)").click()

    page.get_by_text("-07-19 (30)").click()

    page.get_by_role("columnheader", name="-07-12 (29)").click()

    page.get_by_text("-07-19 (30)").click()

    page.get_by_text("-07-12 (29)").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("treeitem", name="-06-21 (26) Column").get_by_label("Press SPACE to toggle").click()

    page.locator("#ag-639 > .ag-column-panel > .ag-column-select > .ag-column-select-list > .ag-virtual-list-viewport > .ag-virtual-list-container > div > .ag-column-select-column > .ag-icon").first.click()

    page.get_by_role("checkbox", name="Press SPACE to toggle visibility (hidden)").check()

    page.locator("div:nth-child(2) > .ag-column-select-column").click()

    page.get_by_role("treeitem", name="-07-05 (28) Column").get_by_label("Press SPACE to toggle").click()

    page.locator("div:nth-child(4) > .ag-column-select-column").click()

    page.get_by_role("treeitem", name="-07-26 (31) Column").get_by_label("Press SPACE to toggle visibility (visible)").click()

    page.get_by_role("treeitem", name="-08-09 (33) Column").get_by_label("Press SPACE to toggle visibility (visible)").uncheck()

    page.get_by_role("treeitem", name="-08-16 (34) Column").get_by_label("Press SPACE to toggle visibility (visible)").uncheck()

    page.get_by_role("button", name="columns").nth(1).click()

    with page.expect_download() as download_info:

        page.locator("div:nth-child(3) > .icon").click()

    download = download_info.value

    page.locator("div:nth-child(4) > div > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    with page.expect_download() as download1_info:

        page.locator("div:nth-child(3) > .icon > .icon-color-toolbar-active").click()

    download1 = download1_info.value

    page.locator("i").first.click()

    page.locator("i").nth(2).click()

    page.locator("i").nth(4).click()

    page.locator(".ag-body-viewport.ag-layout-normal.ag-row-animation.ag-has-focus > .ag-center-cols-viewport").click()

    page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.locator("#my-grid > .ag-root-wrapper > .ag-root-wrapper-body > .ag-root > .ag-header > .ag-header-viewport").click()

    with page.expect_download() as download2_info:

        page.locator("div:nth-child(3) > .icon > .icon-color-toolbar-active").click()

    download2 = download2_info.value

    page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.locator("div").filter(has_text=re.compile(r"^Reset Preference$")).first.click()

    page.locator("span").filter(has_text="Demand Plan").first.click()

    page.locator("i").nth(1).click()

    page.locator("i").nth(3).click()

    page.locator("i").nth(1).click()

