# RECORDED_URL: https://qa.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=1
import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator(".d-flex.flex-column.justify-content-center").first.click()
    page.get_by_text("None").first.click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator("span").filter(has_text="Demand Plan").click()
    page.get_by_text("Base Override").click()
    page.get_by_text("Promo Override").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator("span").filter(has_text="LY Actual Demand").click()
    page.get_by_text("YOY % Change").click()
    page.get_by_text("Planner Flag").click()
    page.locator(".overflow-auto > div:nth-child(10)").click()
    page.get_by_text("Imputed Flag").click()
    page.locator("div:nth-child(11)").click()
    page.get_by_text("Planner Flag").click()
    page.get_by_text("Imputed Flag").click()
    page.get_by_text("Promos").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator("span").filter(has_text="Forecast/Actual Demand").click()
    page.locator("span").filter(has_text="AI Total Forecast").click()
    page.locator(".overflow-auto > div:nth-child(6)").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator(".wr-20.font-weight-normal > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator("span").filter(has_text="AI Base Forecast").click()
    page.get_by_text("All").nth(5).click()
    page.get_by_role("button", name="columns").nth(2).click()
    page.get_by_role("textbox", name="Filter Columns Input").click()
    page.get_by_role("textbox", name="Filter Columns Input").fill("05")
    page.get_by_role("checkbox", name="Press SPACE to toggle").uncheck()
    page.locator("div:nth-child(4) > #preference-iconId > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Save Preference").click()
    with page.expect_download() as download_info:
        page.locator("div:nth-child(3) > #export-iconId > .icon-color-toolbar-active").click()
    download = download_info.value
    page.get_by_text("Weekly Summary Product:").click()
    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()
    page.get_by_text("Reset Preference").click()
    page.locator("i").first.click()
    page.locator("i").nth(2).click()
    page.get_by_role("button", name="columns").nth(2).click()
    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()
    page.get_by_role("textbox", name="Filter Columns Input").click()
    page.get_by_role("button", name="columns").nth(2).click()
    page.get_by_role("gridcell", name=" Forecast/Actual Demand").click()
    page.locator("i").nth(4).click()
    page.get_by_text("Forecast Analysis").click()
    page.get_by_text("Alerts").click()
    page.get_by_text("Product Details").click()
    page.locator("aeap-primary-toolbar").get_by_text("Alerts").click()
    page.get_by_text("Export").click()
    page.get_by_text("Alerts").click()
    page.get_by_text("FVA").click()
    page.get_by_text("Alerts").click()
    page.get_by_role("button", name="Reset").nth(1).click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("ITEM")
    page.locator(".search-button").click()
    page.get_by_text("ITEMS").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.get_by_text("Department").click()
    page.get_by_text("BOTTOMS").click()
    page.get_by_text("JACKETS").click()
    page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.pointer.white-background-color > .pointer").first.click()
    page.get_by_text("ResetApply FiltersSplit").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.background-primary-color").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".navigation-icon.zeb-chevron-right").click()
    page.locator(".action-btn > span:nth-child(2)").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Forecast Analysis").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Alerts").click()
