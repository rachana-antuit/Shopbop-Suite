# RECORDED_URL: https://qa.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=4
import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.locator("#Datepick").click()
    page.get_by_text("12").nth(1).click()
    page.get_by_text("30").nth(3).click()
    page.get_by_text("All").nth(2).click()
    page.get_by_role("textbox", name="Search", exact=True).click()
    page.get_by_role("textbox", name="Search", exact=True).fill("no")
    page.locator("#ExportTab").get_by_role("button", name="Reset").click()
    page.locator("#Datepick").click()
    page.get_by_text("5").first.click()
    page.get_by_text("16").nth(1).click()
    page.locator(".aggregate-filter-options > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").first.click()
    page.locator(".d-flex.dropdown-option.align-items-center.p-v-5.p-l-32").first.click()
    page.locator(".aggregate-filter-options > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").first.click()
    with page.expect_download() as download_info:
        page.get_by_role("button", name="Download").click()
    download = download_info.value
    page.get_by_text("All Measures").first.click()
    page.get_by_text("Select All Measures").click()
    page.get_by_text("Demand Plan").click()
    page.get_by_text("Base Override").click()
    page.get_by_text("AI Total Forecast").click()
    page.get_by_text("Promo Override").click()
    page.get_by_text("Forecast/Actual Demand").click()
    page.locator(".overflow-auto > div:nth-child(5)").click()
    page.get_by_text("LY Actual Demand").click()
    with page.expect_download() as download1_info:
        page.get_by_role("button", name="Download").click()
    download1 = download1_info.value
    page.get_by_text("Role").first.click()
    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(2)").click()
    page.locator(".measure-filter-options > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.get_by_text("YOY % Change").click()
    page.locator(".overflow-auto > div:nth-child(6)").click()
    page.get_by_role("button", name="Download").click()
    page.get_by_text("All Locations").first.click()
    page.locator("div").filter(has_text=re.compile(r"^MARKETPLACE$")).first.click()
    page.get_by_text("All").nth(2).click()
    page.locator("div").filter(has_text=re.compile(r"^Yes$")).first.click()
    page.get_by_role("button", name="Download").click()
    page.get_by_text("Role, Brand").first.click()
    page.locator(".d-flex.dropdown-option.align-items-center.p-v-5.p-l-32").first.click()
    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(2)").click()
    page.locator(".overflow-auto > div:nth-child(3)").click()
    page.get_by_text("All Measures").first.click()
    page.get_by_text("Demand Plan").click()
    page.get_by_text("Base Override").click()
    page.locator(".d-flex.dropdown-option.align-items-center.p-v-5.p-l-32.p-r-16.selected").first.click()
    page.get_by_text("Promo Override", exact=True).click()
    page.get_by_role("button", name="Download").click()
    page.locator(".aggregate-filter-options > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").first.click()
    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").click()
    page.get_by_text("Department").click()
    page.get_by_text("Class").click()
    page.get_by_text("Cluster").click()
    page.locator("div:nth-child(9)").first.click()
    page.get_by_text("Yes").first.click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).nth(3).click()
    page.locator("#location-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()
    page.locator("div").filter(has_text=re.compile(r"^NATIVE$")).nth(1).click()
    page.get_by_text("AI Total Forecast, AI Base").first.click()
    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(2)").click()
    page.locator(".d-flex.dropdown-option.align-items-center.p-v-5.p-l-32").first.click()
    page.get_by_role("button", name="Download").click()
    page.locator(".aggregate-filter-options > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").first.click()
    page.locator("div:nth-child(8)").click()
    page.locator("div:nth-child(10)").click()
    page.get_by_text("Class", exact=True).click()
    page.get_by_text("ResetDownload").click()
    page.locator("#event-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^No$")).nth(1).click()
    page.get_by_text("NATIVE").first.click()
    page.get_by_text("All Locations").click()
    with page.expect_download() as download2_info:
        page.get_by_role("button", name="Download").click()
    download2 = download2_info.value
    page.locator("#ExportTab").get_by_role("button", name="Reset").click()
    page.locator("#ExportTab").get_by_role("button", name="Reset").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("advance")
    page.locator(".search-button").click()
    page.get_by_text("ADVANCED FOOTWEAR").click()
    page.get_by_role("button", name="Apply Filters").click()
    with page.expect_download() as download3_info:
        page.get_by_role("button", name="Download").click()
    download3 = download3_info.value
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("BOOTIES").click()
    page.locator("div").filter(has_text=re.compile(r"^ESPADRILLES$")).click()
    page.locator("div").filter(has_text=re.compile(r"^PUMPS \(HEELS\)$")).click()
    page.locator("div").filter(has_text=re.compile(r"^SLIPPERS$")).click()
    page.get_by_role("button", name="Apply Filters").click()
    with page.expect_download() as download4_info:
        page.get_by_role("button", name="Download").click()
    download4 = download4_info.value
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Alerts").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Forecast Analysis").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Product Details").click()
    page.get_by_label("Split button!").get_by_text("Export").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("FVA").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Home").click()
