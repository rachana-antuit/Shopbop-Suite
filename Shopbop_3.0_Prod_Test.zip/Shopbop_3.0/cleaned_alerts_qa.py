import re

from playwright.sync_api import Page, expect





def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    try: page.goto("https://qa.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=1", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    page.locator(".w-100.p-h-16.p-v-8.dropdown-label.background-white").click()

    page.get_by_role("textbox", name="Search", exact=True).click()

    page.get_by_role("textbox", name="Search", exact=True).fill("stabilit")

    page.locator("#alerts-filterId").get_by_text("Stability").click()

    page.get_by_role("button", name="columns").click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("count")

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()

    page.get_by_text("Alerts Summary columns (0)").click()

    page.locator(".pointer.zeb-adjustments").click()

    page.get_by_text("Save Preference").click()

    with page.expect_download() as download_info:

        page.locator(".icon-color-toolbar-active.zeb-download-underline").click()

    download = download_info.value

    page.get_by_role("button", name="columns").click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.locator(".pointer.zeb-adjustments").click()

    page.get_by_text("Reset Preference").click()

    page.get_by_role("button", name="columns").click()

    page.get_by_role("treeitem", name="Statistical Bias Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Statistical WAPE Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.locator("div:nth-child(5) > .ag-column-select-column > .ag-column-select-checkbox > .ag-wrapper").click()

    page.get_by_role("treeitem", name="Stability Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_text("Alerts Summary columns (0)").click()

    page.locator(".pointer.zeb-adjustments").click()

    page.get_by_text("Save Preference").click()

    with page.expect_download() as download1_info:

        page.locator(".icon-color-toolbar-active.zeb-download-underline").click()

    download1 = download1_info.value

    page.locator(".pointer.zeb-adjustments").click()

    page.get_by_text("Reset Preference").click()

    page.get_by_text("ADDAS-adidas").click(button="right")

    page.get_by_text("Drill down").click()

    page.get_by_role("row", name="ADDAS3094128A9F-Samba OG").get_by_role("checkbox").check()

    page.get_by_role("row", name="ADDAS3094328AA1-Handball").get_by_role("checkbox").check()

    page.get_by_role("row", name="ADDAS3094628AA4-Handball").get_by_role("checkbox").check()

    page.get_by_role("gridcell", name="ADDAS3095328AAF-Japan").get_by_role("checkbox").check()

    page.get_by_role("row", name="ADDAS3096328ABC-Adistar").get_by_role("checkbox").check()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator("#AlertsTab").get_by_role("button", name="Reset").click()

    page.get_by_role("treegrid").get_by_text("ADDAS-adidas").dblclick()

    page.get_by_role("row", name="ADDAS3094128A9F-Samba OG").get_by_role("checkbox").check()

    page.get_by_role("row", name="ADDAS3094328AA1-Handball").get_by_role("checkbox").check()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.get_by_role("button", name="Reset").nth(1).click()

    page.get_by_role("treegrid").get_by_text("Stability").click()

    page.get_by_role("treegrid").get_by_text("Stability").click()

    page.get_by_role("treegrid").get_by_text("Stability").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_role("spinbutton", name="Filter Value").click()

    page.get_by_role("spinbutton", name="Filter Value").fill("40")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.locator("#ag-2361-display").click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active").click()

    page.get_by_text("Does not equal").click()

    page.get_by_text("Greater than", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Greater than").click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-cell.ag-header-parent-hidden.ag-header-cell-sortable.ag-header-background.ag-focus-managed.ag-header-cell-filtered > .ag-header-cell-resize").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Equals").click()

    page.get_by_role("option", name="Less than", exact=True).click()

    page.locator("#ag-2601-input").click()

    page.locator("#ag-2601-input").fill("68")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Greater than or equal to").click()

    page.locator(".ag-icon.ag-icon-small-down").first.click()

    page.get_by_text("Less than").click()

    page.get_by_text("Less than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Equals").click()

    page.get_by_role("option", name="Between").click()

    page.get_by_role("spinbutton", name="Filter from value").click()

    page.get_by_role("spinbutton", name="Filter from value").fill("25")

    page.get_by_role("spinbutton", name="Filter to Value").click()

    page.get_by_role("spinbutton", name="Filter to Value").fill("58")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.locator("a").filter(has_text="2").click()

    page.locator(".zeb-nav-to-last").click()

    page.locator(".zeb-chevron-left").click()

    page.locator(".zeb-nav-to-first").click()

    page.locator(".pagination-next > .zeb-chevron-right").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Equals").click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_text("Blank").click()

    page.get_by_role("option", name="Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(3).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_text("Product Count").click()

    page.get_by_text("Product Count").click()

    page.get_by_text("Product Count").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_role("spinbutton", name="Filter Value").click()

    page.get_by_role("spinbutton", name="Filter Value").fill("13")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.locator("#ag-4138-display").click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Does not equal").click()

    page.get_by_role("option", name="Greater than", exact=True).click()

    page.locator("#ag-4140-input").click()

    page.locator("#ag-4140-input").fill("5")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Greater than").click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Equals").click()

    page.get_by_text("Less than or equal to").click()

    page.locator("#ag-4339-input").click()

    page.locator("#ag-4339-input").fill("9")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_role("option", name="Between").click()

    page.get_by_role("spinbutton", name="Filter to Value").click()

    page.get_by_role("spinbutton", name="Filter to Value").fill("12")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Equals").click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_text("Blank").click()

    page.get_by_text("Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Product Count").click()

    page.get_by_text("Product Count").click()

    page.get_by_title("Filter").nth(4).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_text("Product Count").click()

    page.get_by_text("Location Count").click()

    page.get_by_text("Location Count").click()

    page.get_by_text("Location Count").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Equals").click()

    page.get_by_role("option", name="Equals").click()

    page.get_by_role("spinbutton", name="Filter Value").click()

    page.get_by_role("spinbutton", name="Filter Value").fill("1")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Location Count").click()

    page.get_by_text("Location Count").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_role("combobox", name="Filtering operator").first.click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Location Count").click()

    page.get_by_text("Location Count").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active").click()

    page.get_by_text("Does not equal").click()

    page.get_by_role("option", name="Greater than", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Location Count").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Greater than").click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_role("option", name="Less than", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_role("combobox", name="Filtering operator").first.click()

    page.get_by_text("Less than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Less than or equal to").click()

    page.get_by_role("option", name="Between").click()

    page.get_by_role("spinbutton", name="Filter to Value").click()

    page.get_by_role("spinbutton", name="Filter to Value").fill("2")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Between").click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Location Count").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_text("Blank AND OR Equals").click()

    page.get_by_role("combobox", name="Filtering operator").first.click()

    page.get_by_text("Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.get_by_text("Location Count").click()

    page.get_by_text("Location Count").click()

    page.get_by_title("Filter").nth(5).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_text("View 10 row(s)").first.click()

    page.get_by_text("View 20 row(s)").click()

    page.get_by_text("View 20 row(s)").first.click()

    page.get_by_text("View 10 row(s)").click()

    page.get_by_role("treegrid").get_by_text("AGOLE-AGOLDE").dblclick()

    page.get_by_role("row", name="AGOLE3033540968-Riley High").get_by_role("checkbox").check()

    page.get_by_role("row", name="AGOLE30769102CA-Bryce Cap").get_by_role("checkbox").check()

    page.get_by_role("row", name="AGOLE3084610642-Low Slung").get_by_role("checkbox").check()

    page.get_by_role("row", name="AGOLE30893206AB-Ren: High").get_by_role("checkbox").check()

    page.get_by_role("row", name="AGOLE310811C925-Shrunken").get_by_role("checkbox").check()

    page.get_by_role("gridcell", name="AGOLE311412563E-Ren High Rise").get_by_role("checkbox").check()

    page.locator(".ag-row-even.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0.ag-row-position-absolute.ag-row-hover > .ag-cell-value > .ag-cell-wrapper > .ag-group-value > aeap-group-cell-renderer > .d-flex.align-items-center.w-fit-content > .d-flex").check()

    page.locator(".ag-row-odd.ag-row-no-focus.ag-row-not-inline-editing.ag-row.ag-row-level-0.ag-row-position-absolute.ag-row-hover > .ag-cell-value > .ag-cell-wrapper > .ag-group-value > aeap-group-cell-renderer > .d-flex.align-items-center.w-fit-content > .d-flex").check()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.get_by_text("Show All Locations").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("Sta")

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()

    page.locator("span:nth-child(5) > esp-grid-icons-component > .display-grid-icons > div:nth-child(2) > #preference-iconId > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    with page.expect_download() as download2_info:

        page.locator("span:nth-child(5) > esp-grid-icons-component > .display-grid-icons > div > #export-iconId > .icon-color-toolbar-active").click()

    download2 = download2_info.value

    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Reset Preference").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("treeitem", name="Statistical Bias Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Statistical WAPE Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Stability Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Product Count Column").get_by_label("Press SPACE to toggle").dblclick()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.get_by_role("button", name="columns").nth(1).click()

    page.locator(".d-flex.align-items-center.w-fit-content.selection-row.w-100 > .d-flex").uncheck()

    page.get_by_role("button", name="Reset").nth(2).click()

    page.get_by_role("button", name="Apply").nth(2).click()

    page.locator("#time-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("div").filter(has_text=re.compile(r"^Latest 4 Next 13$")).nth(1).click()

    page.locator("#time-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()

    page.locator("div").filter(has_text=re.compile(r"^Latest 13 Next 13$")).nth(1).click()

    page.locator("button").filter(has_text=re.compile(r"^Apply$")).click()

    page.locator("#time-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()

    page.get_by_text("Latest 52 Next").click()

    page.locator("#time-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()

    page.get_by_text("Latest 104 Next").click()

    page.locator("button").filter(has_text=re.compile(r"^Apply$")).click()

    page.get_by_text("All Events").first.click()

    page.get_by_role("textbox", name="Search", exact=True).click()

    page.get_by_role("textbox", name="Search", exact=True).fill("no")

    page.locator("div").filter(has_text=re.compile(r"^No$")).nth(3).click()

    page.locator("button").filter(has_text=re.compile(r"^Apply$")).click()

    page.locator("#time-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()

    page.locator("div").filter(has_text=re.compile(r"^Latest 4 Next 4$")).first.click()

    page.locator("button").filter(has_text=re.compile(r"^Apply$")).click()

    page.locator("#AlertsTab button").filter(has_text=re.compile(r"^Reset$")).click()

    page.locator(".ellipses > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("dp-line-bar-chart").get_by_text("Base Override").click()

    page.locator("dp-line-bar-chart").get_by_text("Base Override").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").first.click()

    page.locator(".overflow-auto > div:nth-child(9)").click()

    page.get_by_text("Weekly Trend Product:").click()

    page.get_by_text("All selected").first.click()

    page.locator(".d-flex.flex-column.justify-content-center").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".overflow-auto > div:nth-child(3)").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".overflow-auto > div:nth-child(5)").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").click()

    page.get_by_text("Demand Plan Forecast/Actual").click()

    page.locator("div:nth-child(8) > .d-flex").click()

    page.locator("div:nth-child(7) > .d-flex").click()

    page.locator("div:nth-child(6) > .d-flex").click()

    page.locator(".d-flex.dropdown-option.align-items-center.p-v-5.p-l-32.p-r-16.selected").first.click()

    page.locator(".overflow-auto > div:nth-child(3) > .d-flex").click()

    page.locator(".overflow-auto > div:nth-child(2) > .d-flex").click()

    page.locator(".d-flex.flex-column.justify-content-center").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").click()

    page.get_by_text("All selected").first.click()

    page.locator(".title.d-flex.align-items-center.font-size-16.font-weight-bold.nunito.title-color > .grid-icons-container > esp-grid-icons-component > .display-grid-icons > div > #preference-iconId > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.locator("svg").get_by_text("Demand Plan").click()

    page.locator("svg").get_by_text("Demand Plan").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("AI Total Forecast").click()

    page.locator("svg").get_by_text("AI Total Forecast").click()

    page.locator("svg").get_by_text("LY Actual Demand").click()

    page.locator("svg").get_by_text("LY Actual Demand").click()

    page.locator("svg").get_by_text("Base Override").click()

    page.locator("svg").get_by_text("Base Override").click()

    page.locator("svg").get_by_text("Promo Override").click()

    page.locator("svg").get_by_text("Promo Override").click()

    page.locator("svg").get_by_text("AI Base Forecast").click()

    page.locator("svg").get_by_text("AI Base Forecast").click()

    page.locator("svg").get_by_text("YOY % Change").click()

    page.locator("svg").get_by_text("YOY % Change").click()

    page.locator("svg").get_by_text("AI Promo Forecast").click()

    page.locator("svg").get_by_text("AI Promo Forecast").click()

    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Reset Preference").click()

    page.locator("path:nth-child(36)").dblclick()

    page.locator("path:nth-child(45)").dblclick()

    page.locator("i").first.click()

    page.locator("i").nth(2).click()

    page.locator("i").nth(4).click()

    page.locator("i").nth(5).click()

    page.locator("i").nth(5).click()

    with page.expect_download() as download3_info:

        page.get_by_role("textbox", name="Filter Columns Input").fill("08")

    download3 = download3_info.value

