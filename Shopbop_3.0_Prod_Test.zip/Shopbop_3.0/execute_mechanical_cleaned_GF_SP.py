import re

from playwright.sync_api import Page, expect





TARGET_YAML_FILE = r"C:\Users\YG9387\Desktop\agentic-qa-orchestrator-main\agentic-qa-orchestrator-main\UI\workspaces\Shopbop_3.0\GF_SP_KB.yaml"
__PROJECT_OUTPUT_DIR__ = r"C:\Users\YG9387\Desktop\agentic-qa-orchestrator-main\agentic-qa-orchestrator-main\UI\outputs\Shopbop_3.0"

import os
import sys
import time
import yaml
import atexit
import contextlib
from datetime import datetime
import json

# --- Execution Tracking & Reporting ---
_successful_actions = []
_failed_actions = []

# 🔴 DYNAMIC DIRECTORY FOR EVERY RUN
RUN_TIMESTAMP = datetime.now().strftime("%Y%m%d_%H%M%S")

# Route directly to the absolute UI/outputs/ProjectName/
IMAGE_DIR = os.path.join(__PROJECT_OUTPUT_DIR__, "Mechanical_Images", f"Run_{RUN_TIMESTAMP}")
os.makedirs(IMAGE_DIR, exist_ok=True)

def _generate_execution_report():
    report_dir = os.path.join(__PROJECT_OUTPUT_DIR__, "Execution_Reports")
    os.makedirs(report_dir, exist_ok=True)
    report_path = os.path.join(report_dir, f"Mechanical_Execution_{RUN_TIMESTAMP}.txt")
    
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"Mechanical Execution Report\n")
        f.write("="*80 + "\n\n")
        f.write(f"Total Successful Actions: {len(_successful_actions)}\n")
        f.write(f"Total Failed/Healed Actions: {len(_failed_actions)}\n\n")
        
        f.write("--- ❌ FAILED ACTIONS (Required Healing/Manual) ---\n")
        if _failed_actions:
            for fa in _failed_actions: f.write(f"- {fa}\n")
        else:
            f.write("None! 100% of actions succeeded automatically.\n")
            
        f.write("\n--- ✅ SUCCESSFUL ACTIONS ---\n")
        for sa in _successful_actions: f.write(f"- {sa}\n")
            
    print(f"\n📊 Execution Report saved to: {report_path}\n")

atexit.register(_generate_execution_report)

# --- TELEMETRY & NETWORK TRACKING ---
captured_graphql_apis = []
active_api_calls = 0
IGNORED_ENDPOINTS = ["analytics", "telemetry", "log", "metrics", "heartbeat", "beacon", "socket", "wss", "live", "signalr"]

def handle_request(request):
    global active_api_calls
    if request.resource_type in ["fetch", "xhr"]:
        if not any(ignored in request.url.lower() for ignored in IGNORED_ENDPOINTS):
            active_api_calls += 1

def handle_request_done(request):
    global active_api_calls
    if request.resource_type in ["fetch", "xhr"]:
        if not any(ignored in request.url.lower() for ignored in IGNORED_ENDPOINTS):
            active_api_calls = max(0, active_api_calls - 1)

def get_composite_key(req_data):
    op_name = req_data.get("operationName", "unknown_op")
    try:
        dim_levels = req_data.get("variables", {}).get("query", {}).get("dimensionLevels")
        if dim_levels:
            dim_str = "-".join(str(d) for d in dim_levels) if isinstance(dim_levels, list) else str(dim_levels)
            return f"{op_name}_[{dim_str}]"
    except: pass
    return op_name

def handle_response(response):
    try:
        if response.request.method == "POST":
            post_text = response.request.post_data
            if post_text and '"operationName"' in post_text:
                req_data = json.loads(post_text)
                keys = []
                if isinstance(req_data, dict) and "operationName" in req_data:
                    keys.append((get_composite_key(req_data), req_data))
                elif isinstance(req_data, list):
                    for item in req_data:
                        if isinstance(item, dict) and "operationName" in item:
                            keys.append((get_composite_key(item), item))
                if keys:
                    try:
                        resp_json = response.json()
                        for k, req in keys:
                            captured_graphql_apis.append({
                                "api_key": k,
                                "request": req,
                                "response": resp_json
                            })
                    except: pass
    except: pass

# --- STABILITY ENGINE ---
WAIT_FOR_STABILITY_JS = '''
() => new Promise(resolve => {
    let checkCount = 0;
    const check = () => {
        checkCount++;
        const loaders = document.querySelectorAll('.ag-overlay-loading-wrapper, .spinner, .loading, [aria-busy="true"], .skeleton');
        let isVisible = false;
        for (let i = 0; i < loaders.length; i++) {
            const l = loaders[i];
            const style = window.getComputedStyle(l);
            if (l.offsetWidth > 0 && l.offsetHeight > 0 && style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') {
                isVisible = true; break;
            }
        }
        if (isVisible && checkCount < 100) { setTimeout(check, 100); return; }
        resolve();
    };
    check();
})
'''

def wait_for_stability(page):
    global active_api_calls
    page.wait_for_timeout(50)
    wait_cycles = 0
    # 🔴 CAP NETWORK WAIT AT 1 SECOND (10 cycles * 100ms) to prevent hanging
    while active_api_calls > 0 and wait_cycles < 10: 
        page.wait_for_timeout(100)
        wait_cycles += 1
    try: page.evaluate(WAIT_FOR_STABILITY_JS)
    except: pass
    page.wait_for_timeout(100)

# --- WIDGETS ---
DRAW_CROSSHAIR_JS = '''
([x, y]) => {
    const div = document.createElement('div'); div.id = 'agent-intent-crosshair';
    div.style.cssText = `position:fixed; left:${x-25}px; top:${y-25}px; width:50px; height:50px; border:4px solid #00FF00; border-radius:50%; z-index:2147483647; pointer-events:none; box-shadow:0 0 15px #00FF00;`;
    const dot = document.createElement('div');
    dot.style.cssText = 'position:absolute; left:21px; top:21px; width:8px; height:8px; background-color:#FF0000; border-radius:50%;';
    div.appendChild(dot); document.body.appendChild(div);
}
'''

REMOVE_CROSSHAIR_JS = "() => { const e = document.getElementById('agent-intent-crosshair'); if(e) e.remove(); }"

MANUAL_CAPTURE_JS = '''
() => new Promise(resolve => {
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed; top:0; left:0; width:100vw; height:100vh; z-index:2147483647; cursor:crosshair; background:rgba(255,0,0,0.15);';
    const msg = document.createElement('div');
    msg.innerText = "🎯 TARGET MODE: Click the correct element on the screen to auto-heal";
    msg.style.cssText = 'position:absolute; top:20px; left:50%; transform:translateX(-50%); background:black; color:white; padding:12px 24px; font-size:18px; font-weight:bold; border-radius:8px; pointer-events:none; box-shadow: 0 4px 10px rgba(0,0,0,0.5);';
    overlay.appendChild(msg); document.body.appendChild(overlay);
    overlay.addEventListener('click', (e) => {
        e.preventDefault(); e.stopPropagation(); overlay.remove(); resolve({x: e.clientX, y: e.clientY});
    }, {capture: true, once: true});
})
'''

# --- Python Helper Functions ---
@contextlib.contextmanager
def safe_download(page, timeout_ms=30000):
    class DummyEvent:
        @property
        def value(self): return None
    try:
        with page.expect_download(timeout=timeout_ms) as d: yield d
        _successful_actions.append("Download action completed")
    except Exception as e:
        _failed_actions.append("Download action failed/timed out")
        yield DummyEvent()

def update_yaml_knowledge_base(step_id, healed_coords=None):
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id and healed_coords:
                    s['healed_coords'] = healed_coords
                    s['execution_mode'] = 'HEALED_COORDINATES'
        with open(TARGET_YAML_FILE, 'w', encoding='utf-8') as f: yaml.dump(kb, f, default_flow_style=False, sort_keys=False)
    except: pass

def check_for_healed_coords(step_id):
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id and 'healed_coords' in s: return s['healed_coords']
    except: pass
    return None

def safe_action(page, locator, action_name, step_id, before_path, intent_path, after_path, *args, **kwargs):
    print(f"\n▶ Step {step_id}: {action_name}")
    
    # 🔴 DETECT RIGHT CLICK
    is_right_click = kwargs.get('button') == 'right'
    mouse_click_btn = 'right' if is_right_click else 'left'
    
    # MAP PATHS
    before_path = os.path.join(IMAGE_DIR, os.path.basename(before_path))
    intent_path = os.path.join(IMAGE_DIR, os.path.basename(intent_path))
    after_path = os.path.join(IMAGE_DIR, os.path.basename(after_path))
    
    page.wait_for_timeout(50)
    page.screenshot(path=before_path)
    print(f"  └── 📸 Captured Before: {before_path}")
    
    # 🔴 ADVANCED ANGULAR DOMAIN EXTRACTION
    parent_context = "page_level"
    try:
        # Prevent 30s timeout by ensuring element exists before evaluating
        if locator.count() > 0:
            js_find_parent = '''el => {
                let current = el;
                let gridId = null;
                while (current && current !== document.body && current !== document.documentElement) {
                    if (current.hasAttribute('grid-id')) gridId = current.getAttribute('grid-id');
                    if (current.hasAttribute('data-testid')) return `testid:${current.getAttribute('data-testid')}`;
                    
                    if (current.tagName && current.tagName.includes('-') && !current.tagName.toLowerCase().startsWith('ag-')) {
                        let ctx = current.tagName.toLowerCase();
                        if (gridId) ctx += `_gridId-${gridId}`;
                        return ctx;
                    }
                    
                    if (current.id && current.id !== 'undefined' && !current.id.startsWith('ag-') && !current.id.startsWith('cdk-')) {
                        return `id:${current.id}`;
                    }
                    current = current.parentElement;
                }
                if (gridId) return `ag_grid_id_${gridId}`;
                const rect = el.getBoundingClientRect();
                if (rect) {
                    const qX = Math.floor(rect.left / (window.innerWidth / 2));
                    const qY = Math.floor(rect.top / (window.innerHeight / 2));
                    return `screen_quadrant_${qX}_${qY}`;
                }
                return 'page_level';
            }'''
            extracted_context = locator.first.evaluate(js_find_parent)
            if extracted_context:
                parent_context = extracted_context
                print(f"  └── 🧭 Component Scope: {parent_context}")
    except:
        pass
    
    healed = check_for_healed_coords(step_id)
    target_x, target_y = None, None
    if healed: 
        target_x, target_y = healed['x'], healed['y']
    else:
        try:
            locator.scroll_into_view_if_needed(timeout=500)
            box = locator.bounding_box()
            if box:
                target_x = box['x'] + (box['width'] / 2)
                target_y = box['y'] + (box['height'] / 2)
        except: pass

    if target_x is not None and target_y is not None:
        try:
            page.evaluate(DRAW_CROSSHAIR_JS, [target_x, target_y])
            page.wait_for_timeout(50) 
            page.screenshot(path=intent_path)
            print(f"  └── 🎯 Captured Intent: {intent_path}")
            page.evaluate(REMOVE_CROSSHAIR_JS)
        except: pass

    fallback_success = False
    
    # --- HEALED FALLBACK ROUTING ---
    if healed and action_name in ['click', 'dblclick', 'hover']:
        try:
            if action_name == 'click': page.mouse.click(target_x, target_y, button=mouse_click_btn)
            elif action_name == 'dblclick': page.mouse.dblclick(target_x, target_y, button=mouse_click_btn)
            elif action_name == 'hover': page.mouse.move(target_x, target_y)
            fallback_success = True
            print("  └── ✅ Healed Coordinate action executed.")
        except: pass
    else:
        try:
            if 'timeout' not in kwargs: kwargs['timeout'] = 3000
            getattr(locator, action_name)(*args, **kwargs)
            fallback_success = True
            print("  └── ✅ Native action succeeded.")
        except Exception as e:
            error_msg = str(e)
            print(f"  └── ⚠️ Native action failed: {error_msg.splitlines()[0][:80]}...")
            print("  └── Initiating Autonomous Fallbacks...")
            
            if "strict mode violation" in error_msg.lower() and not fallback_success:
                try: getattr(locator.first, action_name)(*args, **kwargs); fallback_success = True; print("  └── 🛠️ F1 Succeeded.")
                except: pass
                
            if not fallback_success and action_name in ['click', 'dblclick', 'check', 'uncheck', 'hover']:
                try: forced = kwargs.copy(); forced['force'] = True; getattr(locator, action_name)(*args, **forced); fallback_success = True; print("  └── 🛠️ F2 Succeeded.")
                except: pass
                
            if not fallback_success and action_name in ['click', 'check', 'uncheck']:
                try: 
                    if action_name == 'click': 
                        if is_right_click: locator.evaluate("el => el.dispatchEvent(new MouseEvent('contextmenu', {bubbles: true, cancelable: true, view: window, button: 2}))")
                        else: locator.evaluate("el => el.click()")
                    elif action_name == 'check': locator.evaluate("el => { el.checked = true; el.dispatchEvent(new Event('change')); }")
                    elif action_name == 'uncheck': locator.evaluate("el => { el.checked = false; el.dispatchEvent(new Event('change')); }")
                    fallback_success = True; print("  └── 🛠️ F3 Succeeded.")
                except: pass
                
            if not fallback_success and target_x is not None and action_name in ['click', 'dblclick', 'hover']:
                try: 
                    if action_name == 'click': page.mouse.click(target_x, target_y, button=mouse_click_btn)
                    elif action_name == 'hover': page.mouse.move(target_x, target_y)
                    fallback_success = True; print("  └── 🛠️ F4 Succeeded.")
                except: pass
                
            if not fallback_success and "Timeout" in error_msg:
                try: 
                    page.evaluate("() => { document.querySelectorAll('.ag-body-viewport').forEach(v => { v.scrollTop+=300; setTimeout(()=>v.scrollTop-=300, 150); }); }")
                    time.sleep(0.5); getattr(locator, action_name)(*args, **kwargs); fallback_success = True; print("  └── 🛠️ F6 Succeeded.")
                except: pass

    # --- MANUAL MODE OVERRIDE ---
    if not fallback_success:
        print(f"  └── 🛑 ALL FALLBACKS FAILED. INJECTING TARGET MODE...")
        _failed_actions.append(f"Step {step_id}: {action_name}")
        coords = page.evaluate(MANUAL_CAPTURE_JS)
        if coords:
            update_yaml_knowledge_base(step_id, healed_coords=coords)
            try:
                page.evaluate(DRAW_CROSSHAIR_JS, [coords['x'], coords['y']])
                page.wait_for_timeout(100)
                page.screenshot(path=intent_path)
                page.evaluate(REMOVE_CROSSHAIR_JS)
                page.mouse.click(coords['x'], coords['y'], button=mouse_click_btn)
                print("  └── ✅ Manual click executed and HEALED for future runs.")
            except: pass
    else:
        _successful_actions.append(f"Step {step_id}: {action_name}")

    wait_for_stability(page)
    page.screenshot(path=after_path)
    print(f"  └── 📸 Captured After:  {after_path}")
    
    # 🔴 RECORD NEW PATHS AND COMPONENT CONTEXT
    try:
        with open(TARGET_YAML_FILE, 'r', encoding='utf-8') as f: kb = yaml.safe_load(f)
        for sec in kb.get('sections', []):
            for s in sec.get('steps', []):
                if s['step_id'] == step_id:
                    s['baseline_images']['before'] = before_path
                    s['baseline_images']['intent'] = intent_path
                    s['baseline_images']['after'] = after_path
                    s['parent_context'] = parent_context
        with open(TARGET_YAML_FILE, 'w', encoding='utf-8') as f: yaml.dump(kb, f, default_flow_style=False, sort_keys=False)
    except: pass

def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    page.on('response', handle_response)
    page.on('request', handle_request)
    page.on('requestfinished', handle_request_done)
    page.on('requestfailed', handle_request_done)
    try: page.goto("https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=1", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print('\n✅ Initializing Stability Engine...')
    wait_for_stability(page)
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2), 'click', '1_1', 'baselines/step_1_1_before.png', 'baselines/step_1_1_intent.png', 'baselines/step_1_1_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_2', 'baselines/step_1_2_before.png', 'baselines/step_1_2_intent.png', 'baselines/step_1_2_after.png')

    safe_action(page, page.get_by_text("Role 18 selected"), 'click', '1_3', 'baselines/step_1_3_before.png', 'baselines/step_1_3_intent.png', 'baselines/step_1_3_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_4', 'baselines/step_1_4_before.png', 'baselines/step_1_4_intent.png', 'baselines/step_1_4_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_5', 'baselines/step_1_5_before.png', 'baselines/step_1_5_intent.png', 'baselines/step_1_5_after.png')

    safe_action(page, page.get_by_text("Brand 1112 selected"), 'click', '1_6', 'baselines/step_1_6_before.png', 'baselines/step_1_6_intent.png', 'baselines/step_1_6_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_7', 'baselines/step_1_7_before.png', 'baselines/step_1_7_intent.png', 'baselines/step_1_7_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_8', 'baselines/step_1_8_before.png', 'baselines/step_1_8_intent.png', 'baselines/step_1_8_after.png')

    safe_action(page, page.get_by_text("Style 39693 selected"), 'click', '1_9', 'baselines/step_1_9_before.png', 'baselines/step_1_9_intent.png', 'baselines/step_1_9_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_10', 'baselines/step_1_10_before.png', 'baselines/step_1_10_intent.png', 'baselines/step_1_10_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_11', 'baselines/step_1_11_before.png', 'baselines/step_1_11_intent.png', 'baselines/step_1_11_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_12', 'baselines/step_1_12_before.png', 'baselines/step_1_12_intent.png', 'baselines/step_1_12_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_13', 'baselines/step_1_13_before.png', 'baselines/step_1_13_intent.png', 'baselines/step_1_13_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_14', 'baselines/step_1_14_before.png', 'baselines/step_1_14_intent.png', 'baselines/step_1_14_after.png')

    safe_action(page, page.get_by_text("SKU 210319 selected"), 'click', '1_15', 'baselines/step_1_15_before.png', 'baselines/step_1_15_intent.png', 'baselines/step_1_15_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")), 'click', '1_16', 'baselines/step_1_16_before.png', 'baselines/step_1_16_intent.png', 'baselines/step_1_16_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_17', 'baselines/step_1_17_before.png', 'baselines/step_1_17_intent.png', 'baselines/step_1_17_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_18', 'baselines/step_1_18_before.png', 'baselines/step_1_18_intent.png', 'baselines/step_1_18_after.png')

    safe_action(page, page.get_by_text("Department 32 selected"), 'click', '1_19', 'baselines/step_1_19_before.png', 'baselines/step_1_19_intent.png', 'baselines/step_1_19_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_20', 'baselines/step_1_20_before.png', 'baselines/step_1_20_intent.png', 'baselines/step_1_20_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_21', 'baselines/step_1_21_before.png', 'baselines/step_1_21_intent.png', 'baselines/step_1_21_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_22', 'baselines/step_1_22_before.png', 'baselines/step_1_22_intent.png', 'baselines/step_1_22_after.png')

    safe_action(page, page.get_by_text("Class 188 selected"), 'click', '1_23', 'baselines/step_1_23_before.png', 'baselines/step_1_23_intent.png', 'baselines/step_1_23_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_24', 'baselines/step_1_24_before.png', 'baselines/step_1_24_intent.png', 'baselines/step_1_24_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Select All$")), 'click', '1_25', 'baselines/step_1_25_before.png', 'baselines/step_1_25_intent.png', 'baselines/step_1_25_after.png')

    safe_action(page, page.get_by_text("Cluster 3 selected"), 'click', '1_26', 'baselines/step_1_26_before.png', 'baselines/step_1_26_intent.png', 'baselines/step_1_26_after.png')

    safe_action(page, page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_27', 'baselines/step_1_27_before.png', 'baselines/step_1_27_intent.png', 'baselines/step_1_27_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_28', 'baselines/step_1_28_before.png', 'baselines/step_1_28_intent.png', 'baselines/step_1_28_after.png')

    safe_action(page, page.get_by_text("Season 27 selected"), 'click', '1_29', 'baselines/step_1_29_before.png', 'baselines/step_1_29_intent.png', 'baselines/step_1_29_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_30', 'baselines/step_1_30_before.png', 'baselines/step_1_30_intent.png', 'baselines/step_1_30_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_31', 'baselines/step_1_31_before.png', 'baselines/step_1_31_intent.png', 'baselines/step_1_31_after.png')

    safe_action(page, page.get_by_text("Replen 9 selected"), 'click', '1_32', 'baselines/step_1_32_before.png', 'baselines/step_1_32_intent.png', 'baselines/step_1_32_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")), 'click', '1_33', 'baselines/step_1_33_before.png', 'baselines/step_1_33_intent.png', 'baselines/step_1_33_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_34', 'baselines/step_1_34_before.png', 'baselines/step_1_34_intent.png', 'baselines/step_1_34_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2), 'click', '1_35', 'baselines/step_1_35_before.png', 'baselines/step_1_35_intent.png', 'baselines/step_1_35_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_36', 'baselines/step_1_36_before.png', 'baselines/step_1_36_intent.png', 'baselines/step_1_36_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_37', 'baselines/step_1_37_before.png', 'baselines/step_1_37_intent.png', 'baselines/step_1_37_after.png')

    safe_action(page, page.locator("pre").filter(has_text="BEAUTY"), 'click', '1_38', 'baselines/step_1_38_before.png', 'baselines/step_1_38_intent.png', 'baselines/step_1_38_after.png')

    safe_action(page, page.get_by_text("Role 1 selected"), 'click', '1_39', 'baselines/step_1_39_before.png', 'baselines/step_1_39_intent.png', 'baselines/step_1_39_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_40', 'baselines/step_1_40_before.png', 'baselines/step_1_40_intent.png', 'baselines/step_1_40_after.png')

    safe_action(page, page.get_by_text("ONESK-111SKIN"), 'click', '1_41', 'baselines/step_1_41_before.png', 'baselines/step_1_41_intent.png', 'baselines/step_1_41_after.png')

    safe_action(page, page.get_by_text("NINNN-19/"), 'click', '1_42', 'baselines/step_1_42_before.png', 'baselines/step_1_42_intent.png', 'baselines/step_1_42_after.png')

    safe_action(page, page.get_by_text("Brand 2 selected"), 'click', '1_43', 'baselines/step_1_43_before.png', 'baselines/step_1_43_intent.png', 'baselines/step_1_43_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_44', 'baselines/step_1_44_before.png', 'baselines/step_1_44_intent.png', 'baselines/step_1_44_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^ONESK30005-Antioxidant Energising Essence$")), 'click', '1_45', 'baselines/step_1_45_before.png', 'baselines/step_1_45_intent.png', 'baselines/step_1_45_after.png')

    safe_action(page, page.get_by_text("Brand 2 selected"), 'click', '1_46', 'baselines/step_1_46_before.png', 'baselines/step_1_46_intent.png', 'baselines/step_1_46_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_47', 'baselines/step_1_47_before.png', 'baselines/step_1_47_intent.png', 'baselines/step_1_47_after.png')

    safe_action(page, page.get_by_text("ONESK3000513153-Antioxidant"), 'click', '1_48', 'baselines/step_1_48_before.png', 'baselines/step_1_48_intent.png', 'baselines/step_1_48_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_49', 'baselines/step_1_49_before.png', 'baselines/step_1_49_intent.png', 'baselines/step_1_49_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_50', 'baselines/step_1_50_before.png', 'baselines/step_1_50_intent.png', 'baselines/step_1_50_after.png')

    safe_action(page, page.get_by_text("ONESK3000513153801-"), 'click', '1_51', 'baselines/step_1_51_before.png', 'baselines/step_1_51_intent.png', 'baselines/step_1_51_after.png')

    safe_action(page, page.get_by_text("SKU 1 selected"), 'click', '1_52', 'baselines/step_1_52_before.png', 'baselines/step_1_52_intent.png', 'baselines/step_1_52_after.png')

    safe_action(page, page.get_by_text("ResetApply FiltersSplit"), 'click', '1_53', 'baselines/step_1_53_before.png', 'baselines/step_1_53_intent.png', 'baselines/step_1_53_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_54', 'baselines/step_1_54_before.png', 'baselines/step_1_54_intent.png', 'baselines/step_1_54_after.png')

    safe_action(page, page.locator(".pointer.zeb-check"), 'click', '1_55', 'baselines/step_1_55_before.png', 'baselines/step_1_55_intent.png', 'baselines/step_1_55_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_56', 'baselines/step_1_56_before.png', 'baselines/step_1_56_intent.png', 'baselines/step_1_56_after.png')

    safe_action(page, page.get_by_title("Save"), 'click', '1_57', 'baselines/step_1_57_before.png', 'baselines/step_1_57_intent.png', 'baselines/step_1_57_after.png')

    safe_action(page, page.locator("input[name=\"filterName\"]"), 'click', '1_58', 'baselines/step_1_58_before.png', 'baselines/step_1_58_intent.png', 'baselines/step_1_58_after.png')

    safe_action(page, page.locator("input[name=\"filterName\"]"), 'fill', '1_59', 'baselines/step_1_59_before.png', 'baselines/step_1_59_intent.png', 'baselines/step_1_59_after.png', "Hierarchy")

    safe_action(page, page.get_by_role("button", name="Save", exact=True), 'click', '1_60', 'baselines/step_1_60_before.png', 'baselines/step_1_60_intent.png', 'baselines/step_1_60_after.png')

    safe_action(page, page.get_by_title("view"), 'click', '1_61', 'baselines/step_1_61_before.png', 'baselines/step_1_61_intent.png', 'baselines/step_1_61_after.png')

    safe_action(page, page.get_by_role("button", name="Edit Filter"), 'click', '1_62', 'baselines/step_1_62_before.png', 'baselines/step_1_62_intent.png', 'baselines/step_1_62_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(5), 'click', '1_63', 'baselines/step_1_63_before.png', 'baselines/step_1_63_intent.png', 'baselines/step_1_63_after.png')

    safe_action(page, page.get_by_text("Role 1 selected"), 'click', '1_64', 'baselines/step_1_64_before.png', 'baselines/step_1_64_intent.png', 'baselines/step_1_64_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^BEAUTY$")), 'click', '1_65', 'baselines/step_1_65_before.png', 'baselines/step_1_65_intent.png', 'baselines/step_1_65_after.png')

    safe_action(page, page.get_by_text("ADVANCED FOOTWEAR"), 'click', '1_66', 'baselines/step_1_66_before.png', 'baselines/step_1_66_intent.png', 'baselines/step_1_66_after.png')

    safe_action(page, page.get_by_text("Role 1 selected"), 'click', '1_67', 'baselines/step_1_67_before.png', 'baselines/step_1_67_intent.png', 'baselines/step_1_67_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_68', 'baselines/step_1_68_before.png', 'baselines/step_1_68_intent.png', 'baselines/step_1_68_after.png')

    safe_action(page, page.get_by_text("PHLII-3.1 Phillip Lim"), 'click', '1_69', 'baselines/step_1_69_before.png', 'baselines/step_1_69_intent.png', 'baselines/step_1_69_after.png')

    safe_action(page, page.get_by_text("Brand 1 selected"), 'click', '1_70', 'baselines/step_1_70_before.png', 'baselines/step_1_70_intent.png', 'baselines/step_1_70_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_71', 'baselines/step_1_71_before.png', 'baselines/step_1_71_intent.png', 'baselines/step_1_71_after.png')

    safe_action(page, page.get_by_text("PHLII2561113711-Alexa Chelsea"), 'click', '1_72', 'baselines/step_1_72_before.png', 'baselines/step_1_72_intent.png', 'baselines/step_1_72_after.png')

    safe_action(page, page.get_by_text("PHLII2605313128-Alexa Moto"), 'click', '1_73', 'baselines/step_1_73_before.png', 'baselines/step_1_73_intent.png', 'baselines/step_1_73_after.png')

    safe_action(page, page.get_by_text("Brand Style Color 2 selected"), 'click', '1_74', 'baselines/step_1_74_before.png', 'baselines/step_1_74_intent.png', 'baselines/step_1_74_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_75', 'baselines/step_1_75_before.png', 'baselines/step_1_75_intent.png', 'baselines/step_1_75_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^PHLII2561113711167-Alexa Chelsea Boots 70mm - Cognac - 35$")), 'click', '1_76', 'baselines/step_1_76_before.png', 'baselines/step_1_76_intent.png', 'baselines/step_1_76_after.png')

    safe_action(page, page.locator("pre").filter(has_text="PHLII2561113711330-Alexa"), 'click', '1_77', 'baselines/step_1_77_before.png', 'baselines/step_1_77_intent.png', 'baselines/step_1_77_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^PHLII2561113711186-Alexa Chelsea Boots 70mm - Cognac - 36$")), 'click', '1_78', 'baselines/step_1_78_before.png', 'baselines/step_1_78_intent.png', 'baselines/step_1_78_after.png')

    safe_action(page, page.get_by_text("SKU 3 selected"), 'click', '1_79', 'baselines/step_1_79_before.png', 'baselines/step_1_79_intent.png', 'baselines/step_1_79_after.png')

    safe_action(page, page.get_by_title("Save"), 'click', '1_80', 'baselines/step_1_80_before.png', 'baselines/step_1_80_intent.png', 'baselines/step_1_80_after.png')

    safe_action(page, page.locator(".p-l-16.panel-icons-container").first, 'click', '1_81', 'baselines/step_1_81_before.png', 'baselines/step_1_81_intent.png', 'baselines/step_1_81_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Role$")), 'click', '1_82', 'baselines/step_1_82_before.png', 'baselines/step_1_82_intent.png', 'baselines/step_1_82_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Brand$")), 'click', '1_83', 'baselines/step_1_83_before.png', 'baselines/step_1_83_intent.png', 'baselines/step_1_83_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^3\.1 Phillip Lim$")), 'click', '1_84', 'baselines/step_1_84_before.png', 'baselines/step_1_84_intent.png', 'baselines/step_1_84_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Brand Style Color$")), 'click', '1_85', 'baselines/step_1_85_before.png', 'baselines/step_1_85_intent.png', 'baselines/step_1_85_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac$")), 'click', '1_86', 'baselines/step_1_86_before.png', 'baselines/step_1_86_intent.png', 'baselines/step_1_86_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Alexa Moto Boots - Espresso$")), 'click', '1_87', 'baselines/step_1_87_before.png', 'baselines/step_1_87_intent.png', 'baselines/step_1_87_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Product$")), 'click', '1_88', 'baselines/step_1_88_before.png', 'baselines/step_1_88_intent.png', 'baselines/step_1_88_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 35$")), 'click', '1_89', 'baselines/step_1_89_before.png', 'baselines/step_1_89_intent.png', 'baselines/step_1_89_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 36$")), 'click', '1_90', 'baselines/step_1_90_before.png', 'baselines/step_1_90_intent.png', 'baselines/step_1_90_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 35\.5$")), 'click', '1_91', 'baselines/step_1_91_before.png', 'baselines/step_1_91_intent.png', 'baselines/step_1_91_after.png')

    safe_action(page, page.get_by_text("Default Filter"), 'click', '1_92', 'baselines/step_1_92_before.png', 'baselines/step_1_92_intent.png', 'baselines/step_1_92_after.png')

    safe_action(page, page.locator("div").filter(has_text="Default Filter").nth(4), 'click', '1_93', 'baselines/step_1_93_before.png', 'baselines/step_1_93_intent.png', 'baselines/step_1_93_after.png')

    safe_action(page, page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer"), 'click', '1_94', 'baselines/step_1_94_before.png', 'baselines/step_1_94_intent.png', 'baselines/step_1_94_after.png')

    safe_action(page, page.locator(".pointer.zeb-check"), 'click', '1_95', 'baselines/step_1_95_before.png', 'baselines/step_1_95_intent.png', 'baselines/step_1_95_after.png')

    safe_action(page, page.get_by_role("button", name="Cancel"), 'click', '1_96', 'baselines/step_1_96_before.png', 'baselines/step_1_96_intent.png', 'baselines/step_1_96_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_97', 'baselines/step_1_97_before.png', 'baselines/step_1_97_intent.png', 'baselines/step_1_97_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_98', 'baselines/step_1_98_before.png', 'baselines/step_1_98_intent.png', 'baselines/step_1_98_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_99', 'baselines/step_1_99_before.png', 'baselines/step_1_99_intent.png', 'baselines/step_1_99_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_100', 'baselines/step_1_100_before.png', 'baselines/step_1_100_intent.png', 'baselines/step_1_100_after.png')

    safe_action(page, page.get_by_text("ACCESSORIES", exact=True), 'click', '1_101', 'baselines/step_1_101_before.png', 'baselines/step_1_101_intent.png', 'baselines/step_1_101_after.png')

    safe_action(page, page.get_by_text("BAGS", exact=True), 'click', '1_102', 'baselines/step_1_102_before.png', 'baselines/step_1_102_intent.png', 'baselines/step_1_102_after.png')

    safe_action(page, page.get_by_text("Department 2 selected"), 'click', '1_103', 'baselines/step_1_103_before.png', 'baselines/step_1_103_intent.png', 'baselines/step_1_103_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_104', 'baselines/step_1_104_before.png', 'baselines/step_1_104_intent.png', 'baselines/step_1_104_after.png')

    safe_action(page, page.get_by_text("BACKPACK"), 'click', '1_105', 'baselines/step_1_105_before.png', 'baselines/step_1_105_intent.png', 'baselines/step_1_105_after.png')

    safe_action(page, page.get_by_text("Class 1 selected"), 'click', '1_106', 'baselines/step_1_106_before.png', 'baselines/step_1_106_intent.png', 'baselines/step_1_106_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_107', 'baselines/step_1_107_before.png', 'baselines/step_1_107_intent.png', 'baselines/step_1_107_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^A$")), 'click', '1_108', 'baselines/step_1_108_before.png', 'baselines/step_1_108_intent.png', 'baselines/step_1_108_after.png')

    safe_action(page, page.get_by_text("Cluster 1 selected"), 'click', '1_109', 'baselines/step_1_109_before.png', 'baselines/step_1_109_intent.png', 'baselines/step_1_109_after.png')

    safe_action(page, page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_110', 'baselines/step_1_110_before.png', 'baselines/step_1_110_intent.png', 'baselines/step_1_110_after.png')

    safe_action(page, page.get_by_text("NO SEASON"), 'click', '1_111', 'baselines/step_1_111_before.png', 'baselines/step_1_111_intent.png', 'baselines/step_1_111_after.png')

    safe_action(page, page.get_by_text("Season 1 selected"), 'click', '1_112', 'baselines/step_1_112_before.png', 'baselines/step_1_112_intent.png', 'baselines/step_1_112_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_113', 'baselines/step_1_113_before.png', 'baselines/step_1_113_intent.png', 'baselines/step_1_113_after.png')

    safe_action(page, page.get_by_text("ATS"), 'click', '1_114', 'baselines/step_1_114_before.png', 'baselines/step_1_114_intent.png', 'baselines/step_1_114_after.png')

    safe_action(page, page.get_by_text("Replen 1 selected"), 'click', '1_115', 'baselines/step_1_115_before.png', 'baselines/step_1_115_intent.png', 'baselines/step_1_115_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_116', 'baselines/step_1_116_before.png', 'baselines/step_1_116_intent.png', 'baselines/step_1_116_after.png')

    safe_action(page, page.locator(".aggrigate-panel"), 'click', '1_117', 'baselines/step_1_117_before.png', 'baselines/step_1_117_intent.png', 'baselines/step_1_117_after.png')

    safe_action(page, page.locator(".aggrigate-panel"), 'click', '1_118', 'baselines/step_1_118_before.png', 'baselines/step_1_118_intent.png', 'baselines/step_1_118_after.png')

    safe_action(page, page.locator(".pointer.zeb-check"), 'click', '1_119', 'baselines/step_1_119_before.png', 'baselines/step_1_119_intent.png', 'baselines/step_1_119_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_120', 'baselines/step_1_120_before.png', 'baselines/step_1_120_intent.png', 'baselines/step_1_120_after.png')

    safe_action(page, page.locator(".navigation-icon.zeb-chevron-right"), 'click', '1_121', 'baselines/step_1_121_before.png', 'baselines/step_1_121_intent.png', 'baselines/step_1_121_after.png')

    safe_action(page, page.locator(".pill-container"), 'click', '1_122', 'baselines/step_1_122_before.png', 'baselines/step_1_122_intent.png', 'baselines/step_1_122_after.png')

    safe_action(page, page.locator("span").filter(has_text="BAGS"), 'click', '1_123', 'baselines/step_1_123_before.png', 'baselines/step_1_123_intent.png', 'baselines/step_1_123_after.png')

    safe_action(page, page.get_by_text("ACCESSORIES"), 'click', '1_124', 'baselines/step_1_124_before.png', 'baselines/step_1_124_intent.png', 'baselines/step_1_124_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_125', 'baselines/step_1_125_before.png', 'baselines/step_1_125_intent.png', 'baselines/step_1_125_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_126', 'baselines/step_1_126_before.png', 'baselines/step_1_126_intent.png', 'baselines/step_1_126_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_127', 'baselines/step_1_127_before.png', 'baselines/step_1_127_intent.png', 'baselines/step_1_127_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_128', 'baselines/step_1_128_before.png', 'baselines/step_1_128_intent.png', 'baselines/step_1_128_after.png')

    safe_action(page, page.get_by_text("ACCESSORIES", exact=True), 'click', '1_129', 'baselines/step_1_129_before.png', 'baselines/step_1_129_intent.png', 'baselines/step_1_129_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_130', 'baselines/step_1_130_before.png', 'baselines/step_1_130_intent.png', 'baselines/step_1_130_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_131', 'baselines/step_1_131_before.png', 'baselines/step_1_131_intent.png', 'baselines/step_1_131_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_132', 'baselines/step_1_132_before.png', 'baselines/step_1_132_intent.png', 'baselines/step_1_132_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_133', 'baselines/step_1_133_before.png', 'baselines/step_1_133_intent.png', 'baselines/step_1_133_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_134', 'baselines/step_1_134_before.png', 'baselines/step_1_134_intent.png', 'baselines/step_1_134_after.png')

    safe_action(page, page.get_by_text("ACTIVE"), 'click', '1_135', 'baselines/step_1_135_before.png', 'baselines/step_1_135_intent.png', 'baselines/step_1_135_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_136', 'baselines/step_1_136_before.png', 'baselines/step_1_136_intent.png', 'baselines/step_1_136_after.png')

    safe_action(page, page.get_by_text("Class 1 selected"), 'click', '1_137', 'baselines/step_1_137_before.png', 'baselines/step_1_137_intent.png', 'baselines/step_1_137_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_138', 'baselines/step_1_138_before.png', 'baselines/step_1_138_intent.png', 'baselines/step_1_138_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^C$")), 'click', '1_139', 'baselines/step_1_139_before.png', 'baselines/step_1_139_intent.png', 'baselines/step_1_139_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_140', 'baselines/step_1_140_before.png', 'baselines/step_1_140_intent.png', 'baselines/step_1_140_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_141', 'baselines/step_1_141_before.png', 'baselines/step_1_141_intent.png', 'baselines/step_1_141_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_142', 'baselines/step_1_142_before.png', 'baselines/step_1_142_intent.png', 'baselines/step_1_142_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_143', 'baselines/step_1_143_before.png', 'baselines/step_1_143_intent.png', 'baselines/step_1_143_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Select All$")), 'click', '1_144', 'baselines/step_1_144_before.png', 'baselines/step_1_144_intent.png', 'baselines/step_1_144_after.png')

    safe_action(page, page.locator(".filter-values-options > div:nth-child(3) > .custom-checkbox-wrapper > .pointer"), 'click', '1_145', 'baselines/step_1_145_before.png', 'baselines/step_1_145_intent.png', 'baselines/step_1_145_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_146', 'baselines/step_1_146_before.png', 'baselines/step_1_146_intent.png', 'baselines/step_1_146_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_147', 'baselines/step_1_147_before.png', 'baselines/step_1_147_intent.png', 'baselines/step_1_147_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_148', 'baselines/step_1_148_before.png', 'baselines/step_1_148_intent.png', 'baselines/step_1_148_after.png')

    safe_action(page, page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_149', 'baselines/step_1_149_before.png', 'baselines/step_1_149_intent.png', 'baselines/step_1_149_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_150', 'baselines/step_1_150_before.png', 'baselines/step_1_150_intent.png', 'baselines/step_1_150_after.png')

    safe_action(page, page.get_by_text("CARRY OVER"), 'click', '1_151', 'baselines/step_1_151_before.png', 'baselines/step_1_151_intent.png', 'baselines/step_1_151_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_152', 'baselines/step_1_152_before.png', 'baselines/step_1_152_intent.png', 'baselines/step_1_152_after.png')

    safe_action(page, page.locator(".pill-container"), 'click', '1_153', 'baselines/step_1_153_before.png', 'baselines/step_1_153_intent.png', 'baselines/step_1_153_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="CARRY OVER"), 'click', '1_154', 'baselines/step_1_154_before.png', 'baselines/step_1_154_intent.png', 'baselines/step_1_154_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_155', 'baselines/step_1_155_before.png', 'baselines/step_1_155_intent.png', 'baselines/step_1_155_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_156', 'baselines/step_1_156_before.png', 'baselines/step_1_156_intent.png', 'baselines/step_1_156_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_157', 'baselines/step_1_157_before.png', 'baselines/step_1_157_intent.png', 'baselines/step_1_157_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_158', 'baselines/step_1_158_before.png', 'baselines/step_1_158_intent.png', 'baselines/step_1_158_after.png')

    safe_action(page, page.get_by_text("ATS"), 'click', '1_159', 'baselines/step_1_159_before.png', 'baselines/step_1_159_intent.png', 'baselines/step_1_159_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_160', 'baselines/step_1_160_before.png', 'baselines/step_1_160_intent.png', 'baselines/step_1_160_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill"), 'click', '1_161', 'baselines/step_1_161_before.png', 'baselines/step_1_161_intent.png', 'baselines/step_1_161_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="ATS"), 'click', '1_162', 'baselines/step_1_162_before.png', 'baselines/step_1_162_intent.png', 'baselines/step_1_162_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_163', 'baselines/step_1_163_before.png', 'baselines/step_1_163_intent.png', 'baselines/step_1_163_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_164', 'baselines/step_1_164_before.png', 'baselines/step_1_164_intent.png', 'baselines/step_1_164_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_165', 'baselines/step_1_165_before.png', 'baselines/step_1_165_intent.png', 'baselines/step_1_165_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_166', 'baselines/step_1_166_before.png', 'baselines/step_1_166_intent.png', 'baselines/step_1_166_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_167', 'baselines/step_1_167_before.png', 'baselines/step_1_167_intent.png', 'baselines/step_1_167_after.png')

    safe_action(page, page.get_by_text("BAGS", exact=True), 'click', '1_168', 'baselines/step_1_168_before.png', 'baselines/step_1_168_intent.png', 'baselines/step_1_168_after.png')

    safe_action(page, page.get_by_text("Department 1 selected"), 'click', '1_169', 'baselines/step_1_169_before.png', 'baselines/step_1_169_intent.png', 'baselines/step_1_169_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_170', 'baselines/step_1_170_before.png', 'baselines/step_1_170_intent.png', 'baselines/step_1_170_after.png')

    safe_action(page, page.get_by_text("BACKPACK"), 'click', '1_171', 'baselines/step_1_171_before.png', 'baselines/step_1_171_intent.png', 'baselines/step_1_171_after.png')

    safe_action(page, page.get_by_text("Class 1 selected"), 'click', '1_172', 'baselines/step_1_172_before.png', 'baselines/step_1_172_intent.png', 'baselines/step_1_172_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_173', 'baselines/step_1_173_before.png', 'baselines/step_1_173_intent.png', 'baselines/step_1_173_after.png')

    safe_action(page, page.locator("div:nth-child(4) > .custom-checkbox-wrapper > .pointer"), 'click', '1_174', 'baselines/step_1_174_before.png', 'baselines/step_1_174_intent.png', 'baselines/step_1_174_after.png')

    safe_action(page, page.get_by_text("Cluster 1 selected"), 'click', '1_175', 'baselines/step_1_175_before.png', 'baselines/step_1_175_intent.png', 'baselines/step_1_175_after.png')

    safe_action(page, page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_176', 'baselines/step_1_176_before.png', 'baselines/step_1_176_intent.png', 'baselines/step_1_176_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^FALL 24$")), 'click', '1_177', 'baselines/step_1_177_before.png', 'baselines/step_1_177_intent.png', 'baselines/step_1_177_after.png')

    safe_action(page, page.get_by_text("Season 1 selected"), 'click', '1_178', 'baselines/step_1_178_before.png', 'baselines/step_1_178_intent.png', 'baselines/step_1_178_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_179', 'baselines/step_1_179_before.png', 'baselines/step_1_179_intent.png', 'baselines/step_1_179_after.png')

    safe_action(page, page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer"), 'click', '1_180', 'baselines/step_1_180_before.png', 'baselines/step_1_180_intent.png', 'baselines/step_1_180_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_181', 'baselines/step_1_181_before.png', 'baselines/step_1_181_intent.png', 'baselines/step_1_181_after.png')

    safe_action(page, page.get_by_title("Save"), 'click', '1_182', 'baselines/step_1_182_before.png', 'baselines/step_1_182_intent.png', 'baselines/step_1_182_after.png')

    safe_action(page, page.locator("input[name=\"filterName\"]"), 'click', '1_183', 'baselines/step_1_183_before.png', 'baselines/step_1_183_intent.png', 'baselines/step_1_183_after.png')

    safe_action(page, page.locator("input[name=\"filterName\"]"), 'fill', '1_184', 'baselines/step_1_184_before.png', 'baselines/step_1_184_intent.png', 'baselines/step_1_184_after.png', "attribute_test")

    safe_action(page, page.get_by_role("button", name="Save", exact=True), 'click', '1_185', 'baselines/step_1_185_before.png', 'baselines/step_1_185_intent.png', 'baselines/step_1_185_after.png')

    safe_action(page, page.get_by_title("view"), 'click', '1_186', 'baselines/step_1_186_before.png', 'baselines/step_1_186_intent.png', 'baselines/step_1_186_after.png')

    safe_action(page, page.locator("esp-radio-select-menu").get_by_text("attribute_test"), 'click', '1_187', 'baselines/step_1_187_before.png', 'baselines/step_1_187_intent.png', 'baselines/step_1_187_after.png')

    safe_action(page, page.get_by_text("Attribute / DepartmentBAGS"), 'click', '1_188', 'baselines/step_1_188_before.png', 'baselines/step_1_188_intent.png', 'baselines/step_1_188_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Class$")), 'click', '1_189', 'baselines/step_1_189_before.png', 'baselines/step_1_189_intent.png', 'baselines/step_1_189_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^BACKPACK$")), 'click', '1_190', 'baselines/step_1_190_before.png', 'baselines/step_1_190_intent.png', 'baselines/step_1_190_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Cluster$")), 'click', '1_191', 'baselines/step_1_191_before.png', 'baselines/step_1_191_intent.png', 'baselines/step_1_191_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^C$")), 'click', '1_192', 'baselines/step_1_192_before.png', 'baselines/step_1_192_intent.png', 'baselines/step_1_192_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Season$")), 'click', '1_193', 'baselines/step_1_193_before.png', 'baselines/step_1_193_intent.png', 'baselines/step_1_193_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^FALL 24$")), 'click', '1_194', 'baselines/step_1_194_before.png', 'baselines/step_1_194_intent.png', 'baselines/step_1_194_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Replen$")), 'click', '1_195', 'baselines/step_1_195_before.png', 'baselines/step_1_195_intent.png', 'baselines/step_1_195_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^All$")), 'click', '1_196', 'baselines/step_1_196_before.png', 'baselines/step_1_196_intent.png', 'baselines/step_1_196_after.png')

    safe_action(page, page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer"), 'click', '1_197', 'baselines/step_1_197_before.png', 'baselines/step_1_197_intent.png', 'baselines/step_1_197_after.png')

    safe_action(page, page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer"), 'click', '1_198', 'baselines/step_1_198_before.png', 'baselines/step_1_198_intent.png', 'baselines/step_1_198_after.png')

    safe_action(page, page.get_by_role("button", name="Edit Filter"), 'click', '1_199', 'baselines/step_1_199_before.png', 'baselines/step_1_199_intent.png', 'baselines/step_1_199_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_200', 'baselines/step_1_200_before.png', 'baselines/step_1_200_intent.png', 'baselines/step_1_200_after.png')

    safe_action(page, page.get_by_text("Department 1 selected"), 'click', '1_201', 'baselines/step_1_201_before.png', 'baselines/step_1_201_intent.png', 'baselines/step_1_201_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^BAGS$")), 'click', '1_202', 'baselines/step_1_202_before.png', 'baselines/step_1_202_intent.png', 'baselines/step_1_202_after.png')

    safe_action(page, page.get_by_text("HANDBAGS"), 'click', '1_203', 'baselines/step_1_203_before.png', 'baselines/step_1_203_intent.png', 'baselines/step_1_203_after.png')

    safe_action(page, page.get_by_text("Department 2 selected"), 'click', '1_204', 'baselines/step_1_204_before.png', 'baselines/step_1_204_intent.png', 'baselines/step_1_204_after.png')

    safe_action(page, page.get_by_text("Cluster 1 selected"), 'click', '1_205', 'baselines/step_1_205_before.png', 'baselines/step_1_205_intent.png', 'baselines/step_1_205_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^C$")), 'click', '1_206', 'baselines/step_1_206_before.png', 'baselines/step_1_206_intent.png', 'baselines/step_1_206_after.png')

    safe_action(page, page.get_by_text("Class 1 selected"), 'click', '1_207', 'baselines/step_1_207_before.png', 'baselines/step_1_207_intent.png', 'baselines/step_1_207_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^AVIATOR$")), 'click', '1_208', 'baselines/step_1_208_before.png', 'baselines/step_1_208_intent.png', 'baselines/step_1_208_after.png')

    safe_action(page, page.get_by_text("ACCESSORIES"), 'click', '1_209', 'baselines/step_1_209_before.png', 'baselines/step_1_209_intent.png', 'baselines/step_1_209_after.png')

    safe_action(page, page.get_by_text("BABY BAGS"), 'click', '1_210', 'baselines/step_1_210_before.png', 'baselines/step_1_210_intent.png', 'baselines/step_1_210_after.png')

    safe_action(page, page.get_by_text("Class 3 selected"), 'click', '1_211', 'baselines/step_1_211_before.png', 'baselines/step_1_211_intent.png', 'baselines/step_1_211_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_212', 'baselines/step_1_212_before.png', 'baselines/step_1_212_intent.png', 'baselines/step_1_212_after.png')

    safe_action(page, page.locator("pre").get_by_text("N/A"), 'click', '1_213', 'baselines/step_1_213_before.png', 'baselines/step_1_213_intent.png', 'baselines/step_1_213_after.png')

    safe_action(page, page.get_by_text("Season 1 selected"), 'click', '1_214', 'baselines/step_1_214_before.png', 'baselines/step_1_214_intent.png', 'baselines/step_1_214_after.png')

    safe_action(page, page.get_by_text("FALL 23"), 'click', '1_215', 'baselines/step_1_215_before.png', 'baselines/step_1_215_intent.png', 'baselines/step_1_215_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^CARRY OVER$")), 'click', '1_216', 'baselines/step_1_216_before.png', 'baselines/step_1_216_intent.png', 'baselines/step_1_216_after.png')

    safe_action(page, page.get_by_title("Save"), 'click', '1_217', 'baselines/step_1_217_before.png', 'baselines/step_1_217_intent.png', 'baselines/step_1_217_after.png')

    safe_action(page, page.locator(".filter-action-panel-container > div:nth-child(3)"), 'click', '1_218', 'baselines/step_1_218_before.png', 'baselines/step_1_218_intent.png', 'baselines/step_1_218_after.png')

    safe_action(page, page.get_by_role("button", name="Cancel"), 'click', '1_219', 'baselines/step_1_219_before.png', 'baselines/step_1_219_intent.png', 'baselines/step_1_219_after.png')

    safe_action(page, page.get_by_title("view"), 'click', '1_220', 'baselines/step_1_220_before.png', 'baselines/step_1_220_intent.png', 'baselines/step_1_220_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Department$")), 'click', '1_221', 'baselines/step_1_221_before.png', 'baselines/step_1_221_intent.png', 'baselines/step_1_221_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^All$")).first, 'click', '1_222', 'baselines/step_1_222_before.png', 'baselines/step_1_222_intent.png', 'baselines/step_1_222_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Cluster$")), 'click', '1_223', 'baselines/step_1_223_before.png', 'baselines/step_1_223_intent.png', 'baselines/step_1_223_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^All$")).nth(1), 'click', '1_224', 'baselines/step_1_224_before.png', 'baselines/step_1_224_intent.png', 'baselines/step_1_224_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Class$")), 'click', '1_225', 'baselines/step_1_225_before.png', 'baselines/step_1_225_intent.png', 'baselines/step_1_225_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^ACCESSORIES$")), 'click', '1_226', 'baselines/step_1_226_before.png', 'baselines/step_1_226_intent.png', 'baselines/step_1_226_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^BABY BAGS$")), 'click', '1_227', 'baselines/step_1_227_before.png', 'baselines/step_1_227_intent.png', 'baselines/step_1_227_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^AVIATOR$")), 'click', '1_228', 'baselines/step_1_228_before.png', 'baselines/step_1_228_intent.png', 'baselines/step_1_228_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Replen$")), 'click', '1_229', 'baselines/step_1_229_before.png', 'baselines/step_1_229_intent.png', 'baselines/step_1_229_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^All$")).nth(2), 'click', '1_230', 'baselines/step_1_230_before.png', 'baselines/step_1_230_intent.png', 'baselines/step_1_230_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute / Season$")), 'click', '1_231', 'baselines/step_1_231_before.png', 'baselines/step_1_231_intent.png', 'baselines/step_1_231_after.png')

    safe_action(page, page.get_by_role("dialog").locator("div").filter(has_text=re.compile(r"^CARRY OVER$")), 'click', '1_232', 'baselines/step_1_232_before.png', 'baselines/step_1_232_intent.png', 'baselines/step_1_232_after.png')

    safe_action(page, page.get_by_role("dialog").locator("div").filter(has_text=re.compile(r"^FALL 23$")), 'click', '1_233', 'baselines/step_1_233_before.png', 'baselines/step_1_233_intent.png', 'baselines/step_1_233_after.png')

    safe_action(page, page.get_by_role("button", name="Cancel"), 'click', '1_234', 'baselines/step_1_234_before.png', 'baselines/step_1_234_intent.png', 'baselines/step_1_234_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_235', 'baselines/step_1_235_before.png', 'baselines/step_1_235_intent.png', 'baselines/step_1_235_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2), 'click', '1_236', 'baselines/step_1_236_before.png', 'baselines/step_1_236_intent.png', 'baselines/step_1_236_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_237', 'baselines/step_1_237_before.png', 'baselines/step_1_237_intent.png', 'baselines/step_1_237_after.png')

    safe_action(page, page.get_by_text("Search In:"), 'click', '1_238', 'baselines/step_1_238_before.png', 'baselines/step_1_238_intent.png', 'baselines/step_1_238_after.png')

    safe_action(page, page.get_by_text("All").first, 'click', '1_239', 'baselines/step_1_239_before.png', 'baselines/step_1_239_intent.png', 'baselines/step_1_239_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^All$")).nth(1), 'click', '1_240', 'baselines/step_1_240_before.png', 'baselines/step_1_240_intent.png', 'baselines/step_1_240_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_241', 'baselines/step_1_241_before.png', 'baselines/step_1_241_intent.png', 'baselines/step_1_241_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_242', 'baselines/step_1_242_before.png', 'baselines/step_1_242_intent.png', 'baselines/step_1_242_after.png', "Items")

    safe_action(page, page.locator(".search-button"), 'click', '1_243', 'baselines/step_1_243_before.png', 'baselines/step_1_243_intent.png', 'baselines/step_1_243_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^ITEMS$")), 'click', '1_244', 'baselines/step_1_244_before.png', 'baselines/step_1_244_intent.png', 'baselines/step_1_244_after.png')

    safe_action(page, page.get_by_text("Select AllITEMS"), 'click', '1_245', 'baselines/step_1_245_before.png', 'baselines/step_1_245_intent.png', 'baselines/step_1_245_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_246', 'baselines/step_1_246_before.png', 'baselines/step_1_246_intent.png', 'baselines/step_1_246_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_247', 'baselines/step_1_247_before.png', 'baselines/step_1_247_intent.png', 'baselines/step_1_247_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_248', 'baselines/step_1_248_before.png', 'baselines/step_1_248_intent.png', 'baselines/step_1_248_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Role$")).nth(1), 'click', '1_249', 'baselines/step_1_249_before.png', 'baselines/step_1_249_intent.png', 'baselines/step_1_249_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_250', 'baselines/step_1_250_before.png', 'baselines/step_1_250_intent.png', 'baselines/step_1_250_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_251', 'baselines/step_1_251_before.png', 'baselines/step_1_251_intent.png', 'baselines/step_1_251_after.png', "Item")

    safe_action(page, page.locator(".search-button"), 'click', '1_252', 'baselines/step_1_252_before.png', 'baselines/step_1_252_intent.png', 'baselines/step_1_252_after.png')

    safe_action(page, page.get_by_text("ITEMS"), 'click', '1_253', 'baselines/step_1_253_before.png', 'baselines/step_1_253_intent.png', 'baselines/step_1_253_after.png')

    safe_action(page, page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer"), 'click', '1_254', 'baselines/step_1_254_before.png', 'baselines/step_1_254_intent.png', 'baselines/step_1_254_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_255', 'baselines/step_1_255_before.png', 'baselines/step_1_255_intent.png', 'baselines/step_1_255_after.png')

    safe_action(page, page.locator("esp-multiselect-dropdown").get_by_text("Brand", exact=True), 'click', '1_256', 'baselines/step_1_256_before.png', 'baselines/step_1_256_intent.png', 'baselines/step_1_256_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_257', 'baselines/step_1_257_before.png', 'baselines/step_1_257_intent.png', 'baselines/step_1_257_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_258', 'baselines/step_1_258_before.png', 'baselines/step_1_258_intent.png', 'baselines/step_1_258_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Style$")).nth(1), 'click', '1_259', 'baselines/step_1_259_before.png', 'baselines/step_1_259_intent.png', 'baselines/step_1_259_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_260', 'baselines/step_1_260_before.png', 'baselines/step_1_260_intent.png', 'baselines/step_1_260_after.png')

    safe_action(page, page.get_by_text("VERSA31175-Item Tank Top Dress"), 'click', '1_261', 'baselines/step_1_261_before.png', 'baselines/step_1_261_intent.png', 'baselines/step_1_261_after.png')

    safe_action(page, page.get_by_text("HANKY40867-Key Items Bike"), 'click', '1_262', 'baselines/step_1_262_before.png', 'baselines/step_1_262_intent.png', 'baselines/step_1_262_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_263', 'baselines/step_1_263_before.png', 'baselines/step_1_263_intent.png', 'baselines/step_1_263_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_264', 'baselines/step_1_264_before.png', 'baselines/step_1_264_intent.png', 'baselines/step_1_264_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Brand Style Color$")).first, 'click', '1_265', 'baselines/step_1_265_before.png', 'baselines/step_1_265_intent.png', 'baselines/step_1_265_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_266', 'baselines/step_1_266_before.png', 'baselines/step_1_266_intent.png', 'baselines/step_1_266_after.png')

    safe_action(page, page.get_by_text("VERSA311752113A-Item Tank Top"), 'click', '1_267', 'baselines/step_1_267_before.png', 'baselines/step_1_267_intent.png', 'baselines/step_1_267_after.png')

    safe_action(page, page.get_by_text("HANKY4086712867-Key Items"), 'click', '1_268', 'baselines/step_1_268_before.png', 'baselines/step_1_268_intent.png', 'baselines/step_1_268_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_269', 'baselines/step_1_269_before.png', 'baselines/step_1_269_intent.png', 'baselines/step_1_269_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_270', 'baselines/step_1_270_before.png', 'baselines/step_1_270_intent.png', 'baselines/step_1_270_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^SKU$")).nth(1), 'click', '1_271', 'baselines/step_1_271_before.png', 'baselines/step_1_271_intent.png', 'baselines/step_1_271_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_272', 'baselines/step_1_272_before.png', 'baselines/step_1_272_intent.png', 'baselines/step_1_272_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^VERSA311752113A186-Item Tank Top Dress - 1B000-Black - 36$")), 'click', '1_273', 'baselines/step_1_273_before.png', 'baselines/step_1_273_intent.png', 'baselines/step_1_273_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^VERSA311752113A187-Item Tank Top Dress - 1B000-Black - 38$")), 'click', '1_274', 'baselines/step_1_274_before.png', 'baselines/step_1_274_intent.png', 'baselines/step_1_274_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_275', 'baselines/step_1_275_before.png', 'baselines/step_1_275_intent.png', 'baselines/step_1_275_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_276', 'baselines/step_1_276_before.png', 'baselines/step_1_276_intent.png', 'baselines/step_1_276_after.png')

    safe_action(page, page.locator(".w-100.p-h-16"), 'click', '1_277', 'baselines/step_1_277_before.png', 'baselines/step_1_277_intent.png', 'baselines/step_1_277_after.png')

    safe_action(page, page.get_by_text("Department"), 'click', '1_278', 'baselines/step_1_278_before.png', 'baselines/step_1_278_intent.png', 'baselines/step_1_278_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_279', 'baselines/step_1_279_before.png', 'baselines/step_1_279_intent.png', 'baselines/step_1_279_after.png')

    safe_action(page, page.locator(".filter-values-options"), 'click', '1_280', 'baselines/step_1_280_before.png', 'baselines/step_1_280_intent.png', 'baselines/step_1_280_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_281', 'baselines/step_1_281_before.png', 'baselines/step_1_281_intent.png', 'baselines/step_1_281_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Class$")).nth(1), 'click', '1_282', 'baselines/step_1_282_before.png', 'baselines/step_1_282_intent.png', 'baselines/step_1_282_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_283', 'baselines/step_1_283_before.png', 'baselines/step_1_283_intent.png', 'baselines/step_1_283_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32"), 'click', '1_284', 'baselines/step_1_284_before.png', 'baselines/step_1_284_intent.png', 'baselines/step_1_284_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_285', 'baselines/step_1_285_before.png', 'baselines/step_1_285_intent.png', 'baselines/step_1_285_after.png')

    safe_action(page, page.locator(".filter-values-options"), 'click', '1_286', 'baselines/step_1_286_before.png', 'baselines/step_1_286_intent.png', 'baselines/step_1_286_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_287', 'baselines/step_1_287_before.png', 'baselines/step_1_287_intent.png', 'baselines/step_1_287_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Cluster$")).nth(1), 'click', '1_288', 'baselines/step_1_288_before.png', 'baselines/step_1_288_intent.png', 'baselines/step_1_288_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_289', 'baselines/step_1_289_before.png', 'baselines/step_1_289_intent.png', 'baselines/step_1_289_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32"), 'click', '1_290', 'baselines/step_1_290_before.png', 'baselines/step_1_290_intent.png', 'baselines/step_1_290_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_291', 'baselines/step_1_291_before.png', 'baselines/step_1_291_intent.png', 'baselines/step_1_291_after.png')

    safe_action(page, page.locator(".filter-values-options"), 'click', '1_292', 'baselines/step_1_292_before.png', 'baselines/step_1_292_intent.png', 'baselines/step_1_292_after.png')

    safe_action(page, page.locator(".search-field-container"), 'click', '1_293', 'baselines/step_1_293_before.png', 'baselines/step_1_293_intent.png', 'baselines/step_1_293_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_294', 'baselines/step_1_294_before.png', 'baselines/step_1_294_intent.png', 'baselines/step_1_294_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Season$")).nth(1), 'click', '1_295', 'baselines/step_1_295_before.png', 'baselines/step_1_295_intent.png', 'baselines/step_1_295_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_296', 'baselines/step_1_296_before.png', 'baselines/step_1_296_intent.png', 'baselines/step_1_296_after.png')

    safe_action(page, page.locator(".filter-values-options"), 'click', '1_297', 'baselines/step_1_297_before.png', 'baselines/step_1_297_intent.png', 'baselines/step_1_297_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_298', 'baselines/step_1_298_before.png', 'baselines/step_1_298_intent.png', 'baselines/step_1_298_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Replen$")).nth(1), 'click', '1_299', 'baselines/step_1_299_before.png', 'baselines/step_1_299_intent.png', 'baselines/step_1_299_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_300', 'baselines/step_1_300_before.png', 'baselines/step_1_300_intent.png', 'baselines/step_1_300_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32"), 'click', '1_301', 'baselines/step_1_301_before.png', 'baselines/step_1_301_intent.png', 'baselines/step_1_301_after.png')

    safe_action(page, page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_302', 'baselines/step_1_302_before.png', 'baselines/step_1_302_intent.png', 'baselines/step_1_302_after.png')

    safe_action(page, page.locator(".filter-values-options"), 'click', '1_303', 'baselines/step_1_303_before.png', 'baselines/step_1_303_intent.png', 'baselines/step_1_303_after.png')

    safe_action(page, page.locator(".zeb-close"), 'click', '1_304', 'baselines/step_1_304_before.png', 'baselines/step_1_304_intent.png', 'baselines/step_1_304_after.png')

    safe_action(page, page.locator(".zeb-close"), 'click', '1_305', 'baselines/step_1_305_before.png', 'baselines/step_1_305_intent.png', 'baselines/step_1_305_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_306', 'baselines/step_1_306_before.png', 'baselines/step_1_306_intent.png', 'baselines/step_1_306_after.png', "carry over")

    safe_action(page, page.locator(".search-button"), 'click', '1_307', 'baselines/step_1_307_before.png', 'baselines/step_1_307_intent.png', 'baselines/step_1_307_after.png')

    safe_action(page, page.get_by_text("CARRY OVER"), 'click', '1_308', 'baselines/step_1_308_before.png', 'baselines/step_1_308_intent.png', 'baselines/step_1_308_after.png')

    safe_action(page, page.get_by_text("CARRY OVER"), 'click', '1_309', 'baselines/step_1_309_before.png', 'baselines/step_1_309_intent.png', 'baselines/step_1_309_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_310', 'baselines/step_1_310_before.png', 'baselines/step_1_310_intent.png', 'baselines/step_1_310_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Season$")).nth(1), 'click', '1_311', 'baselines/step_1_311_before.png', 'baselines/step_1_311_intent.png', 'baselines/step_1_311_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_312', 'baselines/step_1_312_before.png', 'baselines/step_1_312_intent.png', 'baselines/step_1_312_after.png')

    safe_action(page, page.get_by_text("Select AllCARRY OVER"), 'click', '1_313', 'baselines/step_1_313_before.png', 'baselines/step_1_313_intent.png', 'baselines/step_1_313_after.png')

    safe_action(page, page.locator("pre"), 'click', '1_314', 'baselines/step_1_314_before.png', 'baselines/step_1_314_intent.png', 'baselines/step_1_314_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_315', 'baselines/step_1_315_before.png', 'baselines/step_1_315_intent.png', 'baselines/step_1_315_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Cluster$")).first, 'click', '1_316', 'baselines/step_1_316_before.png', 'baselines/step_1_316_intent.png', 'baselines/step_1_316_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_317', 'baselines/step_1_317_before.png', 'baselines/step_1_317_intent.png', 'baselines/step_1_317_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_318', 'baselines/step_1_318_before.png', 'baselines/step_1_318_intent.png', 'baselines/step_1_318_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Class$")).first, 'click', '1_319', 'baselines/step_1_319_before.png', 'baselines/step_1_319_intent.png', 'baselines/step_1_319_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_320', 'baselines/step_1_320_before.png', 'baselines/step_1_320_intent.png', 'baselines/step_1_320_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_321', 'baselines/step_1_321_before.png', 'baselines/step_1_321_intent.png', 'baselines/step_1_321_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_322', 'baselines/step_1_322_before.png', 'baselines/step_1_322_intent.png', 'baselines/step_1_322_after.png', "bags")

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'press', '1_323', 'baselines/step_1_323_before.png', 'baselines/step_1_323_intent.png', 'baselines/step_1_323_after.png', "Enter")

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^BABY BAGS$")), 'click', '1_324', 'baselines/step_1_324_before.png', 'baselines/step_1_324_intent.png', 'baselines/step_1_324_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_325', 'baselines/step_1_325_before.png', 'baselines/step_1_325_intent.png', 'baselines/step_1_325_after.png')

    safe_action(page, page.locator(".dropdown-caret"), 'click', '1_326', 'baselines/step_1_326_before.png', 'baselines/step_1_326_intent.png', 'baselines/step_1_326_after.png')

    safe_action(page, page.locator("esp-multiselect-dropdown").get_by_text("Department"), 'click', '1_327', 'baselines/step_1_327_before.png', 'baselines/step_1_327_intent.png', 'baselines/step_1_327_after.png')

    safe_action(page, page.locator(".search-button"), 'click', '1_328', 'baselines/step_1_328_before.png', 'baselines/step_1_328_intent.png', 'baselines/step_1_328_after.png')

    safe_action(page, page.get_by_text("BAGS", exact=True), 'click', '1_329', 'baselines/step_1_329_before.png', 'baselines/step_1_329_intent.png', 'baselines/step_1_329_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_330', 'baselines/step_1_330_before.png', 'baselines/step_1_330_intent.png', 'baselines/step_1_330_after.png')

    safe_action(page, page.locator(".d-flex.p-h-8").first, 'click', '1_331', 'baselines/step_1_331_before.png', 'baselines/step_1_331_intent.png', 'baselines/step_1_331_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="BAGS"), 'click', '1_332', 'baselines/step_1_332_before.png', 'baselines/step_1_332_intent.png', 'baselines/step_1_332_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2), 'click', '1_333', 'baselines/step_1_333_before.png', 'baselines/step_1_333_intent.png', 'baselines/step_1_333_after.png')

    safe_action(page, page.locator(".font-size-18.pointer.zeb-slider-off"), 'click', '1_334', 'baselines/step_1_334_before.png', 'baselines/step_1_334_intent.png', 'baselines/step_1_334_after.png')

    safe_action(page, page.get_by_text("Brand Style Color"), 'click', '1_335', 'baselines/step_1_335_before.png', 'baselines/step_1_335_intent.png', 'baselines/step_1_335_after.png')

    safe_action(page, page.get_by_text("CHIMI3009211409-02 Sunglasses"), 'click', '1_336', 'baselines/step_1_336_before.png', 'baselines/step_1_336_intent.png', 'baselines/step_1_336_after.png')

    safe_action(page, page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper").first, 'click', '1_337', 'baselines/step_1_337_before.png', 'baselines/step_1_337_intent.png', 'baselines/step_1_337_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_338', 'baselines/step_1_338_before.png', 'baselines/step_1_338_intent.png', 'baselines/step_1_338_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_339', 'baselines/step_1_339_before.png', 'baselines/step_1_339_intent.png', 'baselines/step_1_339_after.png', "AEMER300021071B\nAEMER3002212798")

    safe_action(page, page.locator(".search-button"), 'click', '1_340', 'baselines/step_1_340_before.png', 'baselines/step_1_340_intent.png', 'baselines/step_1_340_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_341', 'baselines/step_1_341_before.png', 'baselines/step_1_341_intent.png', 'baselines/step_1_341_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_342', 'baselines/step_1_342_before.png', 'baselines/step_1_342_intent.png', 'baselines/step_1_342_after.png')

    safe_action(page, page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.background-primary-color > .pointer"), 'click', '1_343', 'baselines/step_1_343_before.png', 'baselines/step_1_343_intent.png', 'baselines/step_1_343_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_344', 'baselines/step_1_344_before.png', 'baselines/step_1_344_intent.png', 'baselines/step_1_344_after.png')

    safe_action(page, page.locator(".pill-container"), 'click', '1_345', 'baselines/step_1_345_before.png', 'baselines/step_1_345_intent.png', 'baselines/step_1_345_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="AEMER300021071B-Jalen Slim"), 'click', '1_346', 'baselines/step_1_346_before.png', 'baselines/step_1_346_intent.png', 'baselines/step_1_346_after.png')

    safe_action(page, page.get_by_text("AEMER300021071B-Jalen Slim").nth(2), 'click', '1_347', 'baselines/step_1_347_before.png', 'baselines/step_1_347_intent.png', 'baselines/step_1_347_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="AEMER300021071B-Jalen Slim"), 'click', '1_348', 'baselines/step_1_348_before.png', 'baselines/step_1_348_intent.png', 'baselines/step_1_348_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill").get_by_text("AEMER3002212798-Kinto Sandals"), 'click', '1_349', 'baselines/step_1_349_before.png', 'baselines/step_1_349_intent.png', 'baselines/step_1_349_after.png')

    safe_action(page, page.get_by_role("button", name="Reset"), 'click', '1_350', 'baselines/step_1_350_before.png', 'baselines/step_1_350_intent.png', 'baselines/step_1_350_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2), 'click', '1_351', 'baselines/step_1_351_before.png', 'baselines/step_1_351_intent.png', 'baselines/step_1_351_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_352', 'baselines/step_1_352_before.png', 'baselines/step_1_352_intent.png', 'baselines/step_1_352_after.png')

    safe_action(page, page.get_by_text("Select AllADVANCED"), 'click', '1_353', 'baselines/step_1_353_before.png', 'baselines/step_1_353_intent.png', 'baselines/step_1_353_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_354', 'baselines/step_1_354_before.png', 'baselines/step_1_354_intent.png', 'baselines/step_1_354_after.png')

    safe_action(page, page.get_by_text("BEAUTY"), 'click', '1_355', 'baselines/step_1_355_before.png', 'baselines/step_1_355_intent.png', 'baselines/step_1_355_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_356', 'baselines/step_1_356_before.png', 'baselines/step_1_356_intent.png', 'baselines/step_1_356_after.png')

    safe_action(page, page.get_by_text("Select All"), 'click', '1_357', 'baselines/step_1_357_before.png', 'baselines/step_1_357_intent.png', 'baselines/step_1_357_after.png')

    safe_action(page, page.get_by_text("BEAUTY"), 'click', '1_358', 'baselines/step_1_358_before.png', 'baselines/step_1_358_intent.png', 'baselines/step_1_358_after.png')

    safe_action(page, page.get_by_text("Role 1 selected"), 'click', '1_359', 'baselines/step_1_359_before.png', 'baselines/step_1_359_intent.png', 'baselines/step_1_359_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_360', 'baselines/step_1_360_before.png', 'baselines/step_1_360_intent.png', 'baselines/step_1_360_after.png')

    safe_action(page, page.get_by_text("AGTNT-Agent Nateur"), 'click', '1_361', 'baselines/step_1_361_before.png', 'baselines/step_1_361_intent.png', 'baselines/step_1_361_after.png')

    safe_action(page, page.get_by_text("Brand 1 selected"), 'click', '1_362', 'baselines/step_1_362_before.png', 'baselines/step_1_362_intent.png', 'baselines/step_1_362_after.png')

    safe_action(page, page.get_by_text("ResetApply FiltersSplit"), 'click', '1_363', 'baselines/step_1_363_before.png', 'baselines/step_1_363_intent.png', 'baselines/step_1_363_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_364', 'baselines/step_1_364_before.png', 'baselines/step_1_364_intent.png', 'baselines/step_1_364_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Alerts"), 'click', '1_365', 'baselines/step_1_365_before.png', 'baselines/step_1_365_intent.png', 'baselines/step_1_365_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_366', 'baselines/step_1_366_before.png', 'baselines/step_1_366_intent.png', 'baselines/step_1_366_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Forecast Analysis", exact=True), 'click', '1_367', 'baselines/step_1_367_before.png', 'baselines/step_1_367_intent.png', 'baselines/step_1_367_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_368', 'baselines/step_1_368_before.png', 'baselines/step_1_368_intent.png', 'baselines/step_1_368_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Product Details"), 'click', '1_369', 'baselines/step_1_369_before.png', 'baselines/step_1_369_intent.png', 'baselines/step_1_369_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_370', 'baselines/step_1_370_before.png', 'baselines/step_1_370_intent.png', 'baselines/step_1_370_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Product Details"), 'click', '1_371', 'baselines/step_1_371_before.png', 'baselines/step_1_371_intent.png', 'baselines/step_1_371_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_372', 'baselines/step_1_372_before.png', 'baselines/step_1_372_intent.png', 'baselines/step_1_372_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Export"), 'click', '1_373', 'baselines/step_1_373_before.png', 'baselines/step_1_373_intent.png', 'baselines/step_1_373_after.png')

    safe_action(page, page.locator("esp-simple-side-filter-panel-v1").get_by_role("button", name="Reset"), 'click', '1_374', 'baselines/step_1_374_before.png', 'baselines/step_1_374_intent.png', 'baselines/step_1_374_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_375', 'baselines/step_1_375_before.png', 'baselines/step_1_375_intent.png', 'baselines/step_1_375_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2), 'click', '1_376', 'baselines/step_1_376_before.png', 'baselines/step_1_376_intent.png', 'baselines/step_1_376_after.png')

    safe_action(page, page.locator(".d-flex.p-l-32").first, 'click', '1_377', 'baselines/step_1_377_before.png', 'baselines/step_1_377_intent.png', 'baselines/step_1_377_after.png')

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^Select All$")), 'click', '1_378', 'baselines/step_1_378_before.png', 'baselines/step_1_378_intent.png', 'baselines/step_1_378_after.png')

    safe_action(page, page.get_by_text("ACCESSORIES", exact=True), 'click', '1_379', 'baselines/step_1_379_before.png', 'baselines/step_1_379_intent.png', 'baselines/step_1_379_after.png')

    safe_action(page, page.get_by_text("Department 1 selected"), 'click', '1_380', 'baselines/step_1_380_before.png', 'baselines/step_1_380_intent.png', 'baselines/step_1_380_after.png')

    safe_action(page, page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_381', 'baselines/step_1_381_before.png', 'baselines/step_1_381_intent.png', 'baselines/step_1_381_after.png')

    safe_action(page, page.get_by_text("EYE MASKS"), 'click', '1_382', 'baselines/step_1_382_before.png', 'baselines/step_1_382_intent.png', 'baselines/step_1_382_after.png')

    safe_action(page, page.get_by_text("Class 1 selected"), 'click', '1_383', 'baselines/step_1_383_before.png', 'baselines/step_1_383_intent.png', 'baselines/step_1_383_after.png')

    safe_action(page, page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex"), 'click', '1_384', 'baselines/step_1_384_before.png', 'baselines/step_1_384_intent.png', 'baselines/step_1_384_after.png')

    safe_action(page, page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer").first, 'click', '1_385', 'baselines/step_1_385_before.png', 'baselines/step_1_385_intent.png', 'baselines/step_1_385_after.png')

    safe_action(page, page.get_by_text("Cluster 1 selected"), 'click', '1_386', 'baselines/step_1_386_before.png', 'baselines/step_1_386_intent.png', 'baselines/step_1_386_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_387', 'baselines/step_1_387_before.png', 'baselines/step_1_387_intent.png', 'baselines/step_1_387_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_388', 'baselines/step_1_388_before.png', 'baselines/step_1_388_intent.png', 'baselines/step_1_388_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_389', 'baselines/step_1_389_before.png', 'baselines/step_1_389_intent.png', 'baselines/step_1_389_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Alerts"), 'click', '1_390', 'baselines/step_1_390_before.png', 'baselines/step_1_390_intent.png', 'baselines/step_1_390_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_391', 'baselines/step_1_391_before.png', 'baselines/step_1_391_intent.png', 'baselines/step_1_391_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Forecast Analysis", exact=True), 'click', '1_392', 'baselines/step_1_392_before.png', 'baselines/step_1_392_intent.png', 'baselines/step_1_392_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_393', 'baselines/step_1_393_before.png', 'baselines/step_1_393_intent.png', 'baselines/step_1_393_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Product Details"), 'click', '1_394', 'baselines/step_1_394_before.png', 'baselines/step_1_394_intent.png', 'baselines/step_1_394_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_395', 'baselines/step_1_395_before.png', 'baselines/step_1_395_intent.png', 'baselines/step_1_395_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("FVA"), 'click', '1_396', 'baselines/step_1_396_before.png', 'baselines/step_1_396_intent.png', 'baselines/step_1_396_after.png')

    safe_action(page, page.get_by_role("button", name="Split button!"), 'click', '1_397', 'baselines/step_1_397_before.png', 'baselines/step_1_397_intent.png', 'baselines/step_1_397_after.png')

    safe_action(page, page.get_by_label("Split button!").get_by_text("Export"), 'click', '1_398', 'baselines/step_1_398_before.png', 'baselines/step_1_398_intent.png', 'baselines/step_1_398_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_399', 'baselines/step_1_399_before.png', 'baselines/step_1_399_intent.png', 'baselines/step_1_399_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_400', 'baselines/step_1_400_before.png', 'baselines/step_1_400_intent.png', 'baselines/step_1_400_after.png', "Items")

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'press', '1_401', 'baselines/step_1_401_before.png', 'baselines/step_1_401_intent.png', 'baselines/step_1_401_after.png', "Enter")

    safe_action(page, page.get_by_text("ITEMS"), 'click', '1_402', 'baselines/step_1_402_before.png', 'baselines/step_1_402_intent.png', 'baselines/step_1_402_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_403', 'baselines/step_1_403_before.png', 'baselines/step_1_403_intent.png', 'baselines/step_1_403_after.png')

    safe_action(page, page.locator(".pointer.custom-checkbox-unchecked"), 'click', '1_404', 'baselines/step_1_404_before.png', 'baselines/step_1_404_intent.png', 'baselines/step_1_404_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'click', '1_405', 'baselines/step_1_405_before.png', 'baselines/step_1_405_intent.png', 'baselines/step_1_405_after.png')

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'fill', '1_406', 'baselines/step_1_406_before.png', 'baselines/step_1_406_intent.png', 'baselines/step_1_406_after.png', "Items,bags")

    safe_action(page, page.get_by_role("textbox", name="Press enter to search"), 'press', '1_407', 'baselines/step_1_407_before.png', 'baselines/step_1_407_intent.png', 'baselines/step_1_407_after.png', "Enter")

    safe_action(page, page.locator("div").filter(has_text=re.compile(r"^HANDBAGS$")), 'click', '1_408', 'baselines/step_1_408_before.png', 'baselines/step_1_408_intent.png', 'baselines/step_1_408_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_409', 'baselines/step_1_409_before.png', 'baselines/step_1_409_intent.png', 'baselines/step_1_409_after.png')

    safe_action(page, page.locator("span").filter(has_text="HANDBAGS +"), 'click', '1_410', 'baselines/step_1_410_before.png', 'baselines/step_1_410_intent.png', 'baselines/step_1_410_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill").get_by_text("HANDBAGS", exact=True), 'click', '1_411', 'baselines/step_1_411_before.png', 'baselines/step_1_411_intent.png', 'baselines/step_1_411_after.png')

    safe_action(page, page.locator("span").filter(has_text="HANDBAGS +"), 'click', '1_412', 'baselines/step_1_412_before.png', 'baselines/step_1_412_intent.png', 'baselines/step_1_412_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill").get_by_text("ITEMS"), 'click', '1_413', 'baselines/step_1_413_before.png', 'baselines/step_1_413_intent.png', 'baselines/step_1_413_after.png')

    safe_action(page, page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.background-primary-color > .pointer"), 'click', '1_414', 'baselines/step_1_414_before.png', 'baselines/step_1_414_intent.png', 'baselines/step_1_414_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_415', 'baselines/step_1_415_before.png', 'baselines/step_1_415_intent.png', 'baselines/step_1_415_after.png')

    safe_action(page, page.locator(".pill-container"), 'click', '1_416', 'baselines/step_1_416_before.png', 'baselines/step_1_416_intent.png', 'baselines/step_1_416_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="HANDBAGS"), 'click', '1_417', 'baselines/step_1_417_before.png', 'baselines/step_1_417_intent.png', 'baselines/step_1_417_after.png')

    safe_action(page, page.locator(".pill-nav-btn.pointer"), 'click', '1_418', 'baselines/step_1_418_before.png', 'baselines/step_1_418_intent.png', 'baselines/step_1_418_after.png')

    safe_action(page, page.locator("aeap-active-toolbar-pill span").filter(has_text="ITEMS"), 'click', '1_419', 'baselines/step_1_419_before.png', 'baselines/step_1_419_intent.png', 'baselines/step_1_419_after.png')

    safe_action(page, page.locator("esp-simple-side-filter-panel-v1").get_by_role("button", name="Reset"), 'click', '1_420', 'baselines/step_1_420_before.png', 'baselines/step_1_420_intent.png', 'baselines/step_1_420_after.png')

    safe_action(page, page.get_by_role("button", name="Apply Filters"), 'click', '1_421', 'baselines/step_1_421_before.png', 'baselines/step_1_421_intent.png', 'baselines/step_1_421_after.png')

