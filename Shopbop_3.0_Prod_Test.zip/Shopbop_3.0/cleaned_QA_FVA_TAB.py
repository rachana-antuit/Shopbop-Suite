import re

from playwright.sync_api import Page, expect





def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    try: page.goto("https://qa.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=5", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    page.locator(".w-100.p-h-16.p-v-8.dropdown-label.background-white").first.click()

    page.get_by_role("textbox", name="Search", exact=True).click()

    page.get_by_role("textbox", name="Search", exact=True).fill("YAsh")

    page.get_by_text("Yash Gupta").click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator("#event-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("div").filter(has_text=re.compile(r"^No$")).nth(1).click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator("#event-filterId > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.get_by_role("textbox", name="Search", exact=True).click()

    page.get_by_role("textbox", name="Search", exact=True).fill("yes")

    page.locator("div").filter(has_text=re.compile(r"^Yes$")).nth(3).click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator("#FVATab").get_by_role("button", name="Reset").click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator(".ellipses > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("dp-line-bar-chart span").filter(has_text="Adjusted Scope Count").click()

    page.locator("dp-line-bar-chart span").filter(has_text="Total Scope Count").click()

    page.locator(".overflow-auto > div:nth-child(3)").click()

    page.locator(".overflow-auto > div:nth-child(4)").click()

    page.locator("dp-line-bar-chart span").filter(has_text="User Forecast").click()

    page.locator(".overflow-auto > div:nth-child(5)").click()

    page.locator("div:nth-child(7)").first.click()

    page.locator("dp-line-bar-chart span").filter(has_text="User WAPE").click()

    page.locator("dp-line-bar-chart span").filter(has_text="FVA - WAPE").click()

    page.locator("div:nth-child(8)").first.click()

    page.locator("div:nth-child(6) > .d-flex").click()

    page.locator(".overflow-auto > div:nth-child(5) > .d-flex").click()

    page.locator("div:nth-child(8) > .d-flex").click()

    page.locator(".overflow-auto > div:nth-child(2) > .d-flex").click()

    page.locator(".d-flex.dropdown-option").first.click()

    page.locator("dp-line-bar-chart").get_by_text("Adjusted Scope Count Total").click()

    page.locator("dp-line-bar-chart").get_by_text("Total Scope Count").click()

    page.locator("dp-line-bar-chart").get_by_text("Adjustment Rate").click()

    page.locator("dp-line-bar-chart").get_by_text("System Forecast").click()

    page.locator("dp-line-bar-chart").get_by_text("Forecast/Actual Demand").click()

    page.locator("dp-line-bar-chart").get_by_text("System WAPE").click()

    page.locator("dp-line-bar-chart").get_by_text("User WAPE").click()

    page.locator("dp-line-bar-chart").get_by_text("FVA - WAPE").click()

    page.locator("svg").get_by_text("Adjusted Scope Count").click()

    page.locator("svg").get_by_text("Adjusted Scope Count").click()

    page.locator("svg").get_by_text("Total Scope Count").click()

    page.locator("svg").get_by_text("Total Scope Count").click()

    page.locator("svg").get_by_text("Adjustment Rate").click()

    page.locator("svg").get_by_text("Adjustment Rate").click()

    page.locator("svg").get_by_text("System Forecast").click()

    page.locator("svg").get_by_text("System Forecast").click()

    page.locator("svg").get_by_text("User Forecast").click()

    page.locator("svg").get_by_text("User Forecast").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("System WAPE").click()

    page.locator("svg").get_by_text("System WAPE").click()

    page.locator("svg").get_by_text("FVA - WAPE").click()

    page.locator("svg").get_by_text("FVA - WAPE").click()

    page.locator("svg").get_by_text("User WAPE").click()

    page.locator("svg").get_by_text("User WAPE").click()

    page.locator(".pointer.zeb-adjustments").first.click()

    page.get_by_text("Save Preference").click()

    page.locator("dp-line-bar-chart #preference-iconId").click()

    page.get_by_text("Reset Preference").click()

    page.locator("esp-card-component").filter(has_text="Adjustment summary columns (0").get_by_role("button").click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("07")

    page.get_by_role("treeitem", name="-07-05 (28) Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="-07-12 (29) Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("checkbox", name="Press SPACE to toggle visibility (visible)").uncheck()

    page.locator("div:nth-child(4) > #preference-iconId > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.locator(".icon-color-toolbar-active.zeb-download-underline").first.click()

    page.locator("esp-card-component").filter(has_text="Adjustment summary columns (0").get_by_role("button").click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("")

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Reset Preference").click()

    page.get_by_role("rowgroup").filter(has_text="Measures").click()

    page.get_by_role("columnheader", name="-06-14 (25)").click(button="right")

    page.get_by_text("Sort Ascending").click()

    page.get_by_text("-06-21 (26)").click()

    page.get_by_text("-06-28 (27)").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").dblclick()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.locator("#ag-87 > .ag-column-panel > .ag-column-select > .ag-column-select-list > .ag-virtual-list-viewport > .ag-virtual-list-container > div > .ag-column-select-column").first.click()

    page.get_by_role("checkbox", name="Press SPACE to toggle visibility (hidden)").check()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("WAPE")

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").uncheck()

    page.locator("div:nth-child(2) > #preference-iconId > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.locator(".position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.locator("div:nth-child(4) > div > .componentParentWrapper > esp-grid-container > esp-card-component > .card-container > .title > .grid-icons-container > esp-grid-icons-component > .display-grid-icons > div > #export-iconId > .icon-color-toolbar-active").click()

    page.locator("esp-card-component").filter(has_text="Planner Rank by WAPE columns").locator("#preference-iconId").click()

    page.get_by_text("Reset Preference").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Forecast Analysis").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Product Details").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Export").click()

    page.get_by_label("Split button!").get_by_text("FVA").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Alerts").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("FVA").click()

