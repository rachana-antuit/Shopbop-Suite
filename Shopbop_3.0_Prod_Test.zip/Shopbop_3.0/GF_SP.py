# RECORDED_URL: https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=1
import re
from playwright.sync_api import Page, expect


def test_example(page: Page) -> None:
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Role 18 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Brand 1112 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Style 39693 selected").click()
    page.get_by_text("Brand Style Color").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Brand Style Color").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("SKU 210319 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Department 32 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Class 188 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^Select All$")).click()
    page.get_by_text("Cluster 3 selected").click()
    page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Season 27 selected").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Replen 9 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Select All").click()
    page.locator("pre").filter(has_text="BEAUTY").click()
    page.get_by_text("Role 1 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("ONESK-111SKIN").click()
    page.get_by_text("NINNN-19/").click()
    page.get_by_text("Brand 2 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^ONESK30005-Antioxidant Energising Essence$")).click()
    page.get_by_text("Brand 2 selected").click()
    page.get_by_text("Brand Style Color").click()
    page.get_by_text("ONESK3000513153-Antioxidant").click()
    page.get_by_text("Brand Style Color").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("ONESK3000513153801-").click()
    page.get_by_text("SKU 1 selected").click()
    page.get_by_text("ResetApply FiltersSplit").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".pointer.zeb-check").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_title("Save").click()
    page.locator("input[name=\"filterName\"]").click()
    page.locator("input[name=\"filterName\"]").fill("Hierarchy")
    page.get_by_role("button", name="Save", exact=True).click()
    page.get_by_title("view").click()
    page.get_by_role("button", name="Edit Filter").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(5).click()
    page.get_by_text("Role 1 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^BEAUTY$")).click()
    page.get_by_text("ADVANCED FOOTWEAR").click()
    page.get_by_text("Role 1 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("PHLII-3.1 Phillip Lim").click()
    page.get_by_text("Brand 1 selected").click()
    page.get_by_text("Brand Style Color").click()
    page.get_by_text("PHLII2561113711-Alexa Chelsea").click()
    page.get_by_text("PHLII2605313128-Alexa Moto").click()
    page.get_by_text("Brand Style Color 2 selected").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^PHLII2561113711167-Alexa Chelsea Boots 70mm - Cognac - 35$")).click()
    page.locator("pre").filter(has_text="PHLII2561113711330-Alexa").click()
    page.locator("div").filter(has_text=re.compile(r"^PHLII2561113711186-Alexa Chelsea Boots 70mm - Cognac - 36$")).click()
    page.get_by_text("SKU 3 selected").click()
    page.get_by_title("Save").click()
    page.locator(".p-l-16.panel-icons-container").first.click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Role$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Brand$")).click()
    page.locator("div").filter(has_text=re.compile(r"^3\.1 Phillip Lim$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Brand Style Color$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Alexa Moto Boots - Espresso$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy / Product$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 35$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 36$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Alexa Chelsea Boots 70mm - Cognac - 35\.5$")).click()
    page.get_by_text("Default Filter").click()
    page.locator("div").filter(has_text="Default Filter").nth(4).click()
    page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer").click()
    page.locator(".pointer.zeb-check").click()
    page.get_by_role("button", name="Cancel").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Select All").click()
    page.get_by_text("ACCESSORIES", exact=True).click()
    page.get_by_text("BAGS", exact=True).click()
    page.get_by_text("Department 2 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("BACKPACK").click()
    page.get_by_text("Class 1 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^A$")).click()
    page.get_by_text("Cluster 1 selected").click()
    page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("NO SEASON").click()
    page.get_by_text("Season 1 selected").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("ATS").click()
    page.get_by_text("Replen 1 selected").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".aggrigate-panel").click()
    page.locator(".aggrigate-panel").click()
    page.locator(".pointer.zeb-check").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".navigation-icon.zeb-chevron-right").click()
    page.locator(".pill-container").click()
    page.locator("span").filter(has_text="BAGS").click()
    page.get_by_text("ACCESSORIES").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Select All").click()
    page.get_by_text("ACCESSORIES", exact=True).click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("ACTIVE").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_text("Class 1 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^C$")).click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^Select All$")).click()
    page.locator(".filter-values-options > div:nth-child(3) > .custom-checkbox-wrapper > .pointer").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("CARRY OVER").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".pill-container").click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="CARRY OVER").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("Select All").click()
    page.get_by_text("ATS").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator("aeap-active-toolbar-pill").click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="ATS").click()
    page.get_by_role("button", name="Reset").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Select All").click()
    page.get_by_text("BAGS", exact=True).click()
    page.get_by_text("Department 1 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("BACKPACK").click()
    page.get_by_text("Class 1 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div:nth-child(4) > .custom-checkbox-wrapper > .pointer").click()
    page.get_by_text("Cluster 1 selected").click()
    page.locator("div:nth-child(5) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("div").filter(has_text=re.compile(r"^FALL 24$")).click()
    page.get_by_text("Season 1 selected").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_title("Save").click()
    page.locator("input[name=\"filterName\"]").click()
    page.locator("input[name=\"filterName\"]").fill("attribute_test")
    page.get_by_role("button", name="Save", exact=True).click()
    page.get_by_title("view").click()
    page.locator("esp-radio-select-menu").get_by_text("attribute_test").click()
    page.get_by_text("Attribute / DepartmentBAGS").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Class$")).click()
    page.locator("div").filter(has_text=re.compile(r"^BACKPACK$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Cluster$")).click()
    page.locator("div").filter(has_text=re.compile(r"^C$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Season$")).click()
    page.locator("div").filter(has_text=re.compile(r"^FALL 24$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Replen$")).click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).click()
    page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer").click()
    page.locator(".footer > .d-flex.ng-star-inserted > .custom-checkbox-wrapper > .pointer").click()
    page.get_by_role("button", name="Edit Filter").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.get_by_text("Department 1 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^BAGS$")).click()
    page.get_by_text("HANDBAGS").click()
    page.get_by_text("Department 2 selected").click()
    page.get_by_text("Cluster 1 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^C$")).click()
    page.get_by_text("Class 1 selected").click()
    page.locator("div").filter(has_text=re.compile(r"^AVIATOR$")).click()
    page.get_by_text("ACCESSORIES").click()
    page.get_by_text("BABY BAGS").click()
    page.get_by_text("Class 3 selected").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator("pre").get_by_text("N/A").click()
    page.get_by_text("Season 1 selected").click()
    page.get_by_text("FALL 23").click()
    page.locator("div").filter(has_text=re.compile(r"^CARRY OVER$")).click()
    page.get_by_title("Save").click()
    page.locator(".filter-action-panel-container > div:nth-child(3)").click()
    page.get_by_role("button", name="Cancel").click()
    page.get_by_title("view").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Department$")).click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).first.click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Cluster$")).click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).nth(1).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Class$")).click()
    page.locator("div").filter(has_text=re.compile(r"^ACCESSORIES$")).click()
    page.locator("div").filter(has_text=re.compile(r"^BABY BAGS$")).click()
    page.locator("div").filter(has_text=re.compile(r"^AVIATOR$")).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Replen$")).click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).nth(2).click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute / Season$")).click()
    page.get_by_role("dialog").locator("div").filter(has_text=re.compile(r"^CARRY OVER$")).click()
    page.get_by_role("dialog").locator("div").filter(has_text=re.compile(r"^FALL 23$")).click()
    page.get_by_role("button", name="Cancel").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_text("Search In:").click()
    page.get_by_text("All").first.click()
    page.locator("div").filter(has_text=re.compile(r"^All$")).nth(1).click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("Items")
    page.locator(".search-button").click()
    page.locator("div").filter(has_text=re.compile(r"^ITEMS$")).click()
    page.get_by_text("Select AllITEMS").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_role("button", name="Reset").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Role$")).nth(1).click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("Item")
    page.locator(".search-button").click()
    page.get_by_text("ITEMS").click()
    page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer").click()
    page.locator(".dropdown-caret").click()
    page.locator("esp-multiselect-dropdown").get_by_text("Brand", exact=True).click()
    page.locator(".search-button").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Style$")).nth(1).click()
    page.locator(".search-button").click()
    page.get_by_text("VERSA31175-Item Tank Top Dress").click()
    page.get_by_text("HANKY40867-Key Items Bike").click()
    page.get_by_text("Select All").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Brand Style Color$")).first.click()
    page.locator(".search-button").click()
    page.get_by_text("VERSA311752113A-Item Tank Top").click()
    page.get_by_text("HANKY4086712867-Key Items").click()
    page.get_by_text("Select All").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^SKU$")).nth(1).click()
    page.locator(".search-button").click()
    page.locator("div").filter(has_text=re.compile(r"^VERSA311752113A186-Item Tank Top Dress - 1B000-Black - 36$")).click()
    page.locator("div").filter(has_text=re.compile(r"^VERSA311752113A187-Item Tank Top Dress - 1B000-Black - 38$")).click()
    page.get_by_text("Select All").click()
    page.get_by_text("Select All").click()
    page.locator(".w-100.p-h-16").click()
    page.get_by_text("Department").click()
    page.locator(".search-button").click()
    page.locator(".filter-values-options").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Class$")).nth(1).click()
    page.locator(".search-button").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator(".filter-values-options").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Cluster$")).nth(1).click()
    page.locator(".search-button").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator(".filter-values-options").click()
    page.locator(".search-field-container").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Season$")).nth(1).click()
    page.locator(".search-button").click()
    page.locator(".filter-values-options").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Replen$")).nth(1).click()
    page.locator(".search-button").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex.p-l-32").click()
    page.locator("div:nth-child(6) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator(".filter-values-options").click()
    page.locator(".zeb-close").click()
    page.locator(".zeb-close").click()
    page.get_by_role("textbox", name="Press enter to search").fill("carry over")
    page.locator(".search-button").click()
    page.get_by_text("CARRY OVER").click()
    page.get_by_text("CARRY OVER").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Season$")).nth(1).click()
    page.locator(".search-button").click()
    page.get_by_text("Select AllCARRY OVER").click()
    page.locator("pre").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Cluster$")).first.click()
    page.locator(".search-button").click()
    page.locator(".dropdown-caret").click()
    page.locator("div").filter(has_text=re.compile(r"^Class$")).first.click()
    page.locator(".search-button").click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("bags")
    page.get_by_role("textbox", name="Press enter to search").press("Enter")
    page.locator("div").filter(has_text=re.compile(r"^BABY BAGS$")).click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.locator(".dropdown-caret").click()
    page.locator("esp-multiselect-dropdown").get_by_text("Department").click()
    page.locator(".search-button").click()
    page.get_by_text("BAGS", exact=True).click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".d-flex.p-h-8").first.click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="BAGS").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()
    page.locator(".font-size-18.pointer.zeb-slider-off").click()
    page.get_by_text("Brand Style Color").click()
    page.get_by_text("CHIMI3009211409-02 Sunglasses").click()
    page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper").first.click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("AEMER300021071B\nAEMER3002212798")
    page.locator(".search-button").click()
    page.get_by_text("Select All").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.background-primary-color > .pointer").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".pill-container").click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="AEMER300021071B-Jalen Slim").click()
    page.get_by_text("AEMER300021071B-Jalen Slim").nth(2).click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="AEMER300021071B-Jalen Slim").click()
    page.locator("aeap-active-toolbar-pill").get_by_text("AEMER3002212798-Kinto Sandals").click()
    page.get_by_role("button", name="Reset").click()
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.get_by_text("Select AllADVANCED").click()
    page.get_by_text("Select All").click()
    page.get_by_text("BEAUTY").click()
    page.get_by_text("Select All").click()
    page.get_by_text("Select All").click()
    page.get_by_text("BEAUTY").click()
    page.get_by_text("Role 1 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("AGTNT-Agent Nateur").click()
    page.get_by_text("Brand 1 selected").click()
    page.get_by_text("ResetApply FiltersSplit").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Alerts").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Forecast Analysis", exact=True).click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Product Details").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Product Details").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Export").click()
    page.locator("esp-simple-side-filter-panel-v1").get_by_role("button", name="Reset").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator("div").filter(has_text=re.compile(r"^Attribute$")).nth(2).click()
    page.locator(".d-flex.p-l-32").first.click()
    page.locator("div").filter(has_text=re.compile(r"^Select All$")).click()
    page.get_by_text("ACCESSORIES", exact=True).click()
    page.get_by_text("Department 1 selected").click()
    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.get_by_text("EYE MASKS").click()
    page.get_by_text("Class 1 selected").click()
    page.locator("div:nth-child(4) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()
    page.locator(".filter-values.d-flex.align-items-center.p-l-32.p-r-24 > .custom-checkbox-wrapper > .pointer").first.click()
    page.get_by_text("Cluster 1 selected").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Alerts").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Forecast Analysis", exact=True).click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Product Details").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("FVA").click()
    page.get_by_role("button", name="Split button!").click()
    page.get_by_label("Split button!").get_by_text("Export").click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("Items")
    page.get_by_role("textbox", name="Press enter to search").press("Enter")
    page.get_by_text("ITEMS").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".pointer.custom-checkbox-unchecked").click()
    page.get_by_role("textbox", name="Press enter to search").click()
    page.get_by_role("textbox", name="Press enter to search").fill("Items,bags")
    page.get_by_role("textbox", name="Press enter to search").press("Enter")
    page.locator("div").filter(has_text=re.compile(r"^HANDBAGS$")).click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator("span").filter(has_text="HANDBAGS +").click()
    page.locator("aeap-active-toolbar-pill").get_by_text("HANDBAGS", exact=True).click()
    page.locator("span").filter(has_text="HANDBAGS +").click()
    page.locator("aeap-active-toolbar-pill").get_by_text("ITEMS").click()
    page.locator(".custom-checkbox-wrapper.overflow-hidden.d-flex.justify-content-center.m-r-8.background-primary-color > .pointer").click()
    page.get_by_role("button", name="Apply Filters").click()
    page.locator(".pill-container").click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="HANDBAGS").click()
    page.locator(".pill-nav-btn.pointer").click()
    page.locator("aeap-active-toolbar-pill span").filter(has_text="ITEMS").click()
    page.locator("esp-simple-side-filter-panel-v1").get_by_role("button", name="Reset").click()
    page.get_by_role("button", name="Apply Filters").click()
