import re

from playwright.sync_api import Page, expect





def test_example(page: Page) -> None:
    # --- MFA & Login Wait Block ---
    try: page.goto("https://stage.shopbop.antuit.ai/dp/demand-planning/executive-dashboard?workbookId=6&tabIndex=3", timeout=0)
    except: pass
    print("\n" + "="*60)
    input("ACTION REQUIRED: Log in, pass MFA, then PRESS [ENTER]...\n")
    print("="*60 + "\n")



    # ============================================================
    # SECTION: Default Initialization
    # ============================================================
    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()

    page.locator(".d-flex.p-l-32").first.click()

    page.get_by_text("Select AllADVANCED").click()

    page.get_by_text("Select All").click()

    page.get_by_text("ADVANCED FOOTWEAR").click()

    page.get_by_role("button", name="Apply Filters").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Product Details").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Alerts").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Forecast Analysis", exact=True).click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Export").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("FVA").click()

    page.get_by_role("button", name="Split button!").click()

    page.get_by_label("Split button!").get_by_text("Product Details").click()

    page.get_by_text("AARIG3016939137154", exact=True).click(button="right")

    page.get_by_label("Context Menu").get_by_text("Forecast Analysis", exact=True).click()

    page.get_by_text("ADVANCED FOOTWEAR").click(button="right")

    page.get_by_label("Context Menu").get_by_text("Alerts").click()

    page.get_by_text("LOEFF-Loeffler Randall").click(button="right")

    page.get_by_label("Context Menu").get_by_text("Product Details").click()

    page.locator("#Datepick").click()

    page.get_by_text("2", exact=True).nth(3).click()

    page.get_by_role("button", name="›").click()

    page.get_by_role("button", name="›").click()

    page.get_by_text("22").nth(1).click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.get_by_text("All Events").first.click()

    page.get_by_role("textbox", name="Search", exact=True).click()

    page.get_by_role("textbox", name="Search", exact=True).fill("yes")

    page.locator(".search-field-container.p-v-12").click()

    page.locator("div").filter(has_text=re.compile(r"^Yes$")).nth(2).click()

    page.get_by_text("All Alerts").first.click()

    page.locator("div").filter(has_text=re.compile(r"^Stability$")).nth(1).click()

    page.get_by_text("All Locations").first.click()

    page.get_by_text("MARKETPLACE").click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator("esp-complex-filter").get_by_role("button", name="Reset").click()

    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()

    page.locator("esp-simple-side-filter-panel-v1").get_by_role("button", name="Reset").click()

    page.locator("div").filter(has_text=re.compile(r"^Hierarchy$")).nth(2).click()

    page.locator("div:nth-child(3) > esp-filter-sub-accordion-v1 > .sub-accordion-element > .d-flex").click()

    page.get_by_text("ABCXI-abacaxi").click()

    page.get_by_role("button", name="Apply Filters").click()

    page.get_by_text("Forecast Total columns (0)").click()

    page.locator(".pointer.chevron").click()

    page.locator("i").click()

    page.locator("#Datepick").click()

    page.get_by_text("19").nth(3).click()

    page.get_by_text("17").nth(3).click()

    page.get_by_text("Forecast Total columns (0) TopBottom Drag here to set row groupsDrag here to").click()

    page.locator("#Datepick").click()

    page.get_by_text("19").nth(3).click()

    page.get_by_role("button", name="›").click()

    page.get_by_text("25").nth(2).click()

    page.get_by_text("29").nth(2).click()

    page.get_by_role("button", name="Apply", exact=True).click()

    page.locator(".pointer.chevron").click()

    page.locator(".pointer.chevron").click()

    page.locator(".pointer.chevron").click()

    page.locator(".pointer.chevron").click()

    page.locator("esp-card-component").filter(has_text="Forecast Total columns (0)").get_by_role("button").click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("AI")

    page.get_by_role("treeitem", name="AI Total Forecast Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="AI Base Forecast Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("checkbox", name="Press SPACE to toggle visibility (visible)").uncheck()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("")

    page.locator(".pointer.zeb-adjustments").first.click()

    page.get_by_text("Forecast Total columns (0)").click()

    with page.expect_download() as download_info:

        page.locator(".icon-color-toolbar-active.zeb-download-underline").first.click()

    download = download_info.value

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.get_by_role("treeitem", name="Demand Plan Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="AI Total Forecast Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="AI Base Forecast Column").get_by_label("Press SPACE to toggle").uncheck()

    page.locator("div:nth-child(2) > .ag-column-select-column").click()

    page.get_by_role("treeitem", name="Base Override Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("treeitem", name="Promo Override Column").get_by_label("Press SPACE to toggle").uncheck()

    page.get_by_role("checkbox", name="Press SPACE to toggle visibility (visible)").uncheck()

    page.locator("esp-card-component").filter(has_text="Forecast Total columns (0)").get_by_role("button").click()

    page.locator("esp-card-component").filter(has_text="Forecast Total columns (0)").get_by_role("button").click()

    page.locator(".ag-column-select-header").first.click()

    page.get_by_text("Forecast Total columns (0)").click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.locator("esp-card-component").filter(has_text="Forecast Total columns (0)").get_by_role("button").click()

    page.locator(".pointer.zeb-adjustments").first.click()

    page.get_by_text("Reset Preference").click()

    page.locator(".pointer.zeb-adjustments").first.click()

    page.get_by_text("Reset Preference").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("textbox", name="Filter Columns Input").click()

    page.get_by_role("textbox", name="Filter Columns Input").fill("OVerride")

    page.get_by_role("treeitem", name="Base Override Column").get_by_label("Press SPACE to toggle").uncheck()

    page.locator("div:nth-child(2) > .ag-column-select-column > .ag-column-select-checkbox > .ag-wrapper").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.locator("span:nth-child(5) > esp-grid-icons-component > .display-grid-icons > div:nth-child(3) > div").click()

    page.get_by_text("Save Preference").click()

    with page.expect_download() as download1_info:

        page.locator("div:nth-child(2) > .icon > .icon-color-toolbar-active").click()

    download1 = download1_info.value

    page.locator(".ag-header-icon.ag-header-cell-filter-button").first.click()

    page.get_by_role("textbox", name="Filter Value").click()

    page.get_by_role("textbox", name="Filter Value").fill("ABCXI300421CD2D112")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.locator("#ag-3661-display").click()

    page.get_by_text("Does not contain").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_text("Does not contain").click()

    page.get_by_role("option", name="Equals").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_text("Equals").click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.locator("#ag-4422-input").click()

    page.locator("#ag-4422-input").fill("ABCXI300421CD2D115")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_text("Contains").click()

    page.get_by_role("option", name="Equals").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_text("Contains").click()

    page.get_by_role("option", name="Begins with").click()

    page.get_by_role("textbox", name="Filter Value").click()

    page.get_by_role("textbox", name="Filter Value").fill("ABCXI300442")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button").first.click()

    page.get_by_text("Begins with").click()

    page.get_by_text("Ends with").click()

    page.locator("#ag-3663-input").click()

    page.locator("#ag-3663-input").fill("15")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_role("combobox", name="Filtering operator").first.click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_role("combobox", name="Filtering operator").first.click()

    page.get_by_role("option", name="Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button > .filter-icon").first.click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.locator(".ag-header-cell.ag-column-first.ag-header-parent-hidden.ag-header-cell-sortable > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label").click()

    page.locator(".ag-header-cell.ag-column-first.ag-header-parent-hidden.ag-header-cell-sortable > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-cell-label").click()

    page.get_by_text("SKU 1").click()

    page.get_by_role("textbox", name="Filter Value").click()

    page.get_by_role("textbox", name="Filter Value").fill("ABCXI300421CD2D112-Smocked Silky Leggings - Black - XS")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active").click()

    page.get_by_text("Contains AND OR Contains").click()

    page.get_by_text("Does not contain").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Does not contain").click()

    page.get_by_role("option", name="Equals").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-cell.ag-header-parent-hidden.ag-header-cell-sortable.ag-header-background.ag-focus-managed.ag-header-cell-filtered > .ag-header-cell-resize").click()

    page.locator(".ag-header-cell.ag-header-parent-hidden.ag-header-cell-sortable.ag-header-background.ag-focus-managed.ag-header-cell-filtered > .ag-header-cell-resize").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Equals").click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Does not equal").click()

    page.get_by_role("option", name="Begins with").click()

    page.locator("#ag-7417-input").click()

    page.locator("#ag-7417-input").click()

    page.locator("#ag-7417-input").click()

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").press("ArrowRight")

    page.locator("#ag-7417-input").fill("ABCXI300421")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.locator(".ag-header-cell.ag-header-parent-hidden.ag-header-cell-sortable.ag-header-background.ag-focus-managed.ag-header-active > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-icon > .filter-icon").click()

    page.get_by_text("Contains").click()

    page.get_by_text("Ends with").click()

    page.get_by_role("textbox", name="Filter Value").click()

    page.get_by_role("textbox", name="Filter Value").fill("L")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Ends with AND OR Contains").click()

    page.get_by_text("Ends with").click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.locator(".ag-filter-body-wrapper > .ag-resizer-wrapper > .ag-resizer.ag-resizer-bottom").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Blank").click()

    page.get_by_text("Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.locator("esp-row-dimentional-grid").get_by_text("Demand Plan").click()

    page.locator("esp-row-dimentional-grid").get_by_text("Demand Plan").click()

    page.locator("esp-row-dimentional-grid").get_by_text("Demand Plan").click()

    page.locator(".ag-header-cell.ag-header-parent-hidden.ag-header-cell-sortable.ag-header-background.ag-focus-managed.ag-header-active > .ag-header-cell-comp-wrapper > .ag-cell-label-container > .ag-header-icon > .filter-icon").click()

    page.get_by_role("spinbutton", name="Filter Value").click()

    page.get_by_role("spinbutton", name="Filter Value").fill("0")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.locator("#ag-10418-display").click()

    page.get_by_text("Does not equal").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Does not equal").click()

    page.get_by_text("Greater than", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Greater than").click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Greater than or equal to").click()

    page.get_by_role("option", name="Less than", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Less than").click()

    page.get_by_text("Less than or equal to").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Less than or equal to").click()

    page.get_by_role("option", name="Between").click()

    page.get_by_role("spinbutton", name="Filter to Value").click()

    page.get_by_role("spinbutton", name="Filter to Value").fill("15")

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Between").click()

    page.get_by_role("option", name="Blank", exact=True).click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_text("Blank").click()

    page.get_by_text("Not blank").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Apply").click()

    page.locator("esp-row-dimentional-grid").get_by_text("Demand Plan").click()

    page.locator(".ag-header-icon.ag-header-cell-filter-button.ag-filter-active > .filter-icon").click()

    page.get_by_label("Column Filter").get_by_role("button", name="Reset").click()

    page.get_by_role("button", name="columns").nth(1).click()

    page.get_by_role("checkbox", name="Toggle All Columns Visibility").check()

    page.get_by_text("Products columns (0)").click()

    page.locator(".ng-star-inserted.position-relative > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.get_by_text("123").click()

    page.get_by_text("Showing 10 out of 22 123Rows").click()

    page.locator(".zeb-nav-to-first").click()

    page.get_by_text("123").click()

    page.locator(".zeb-chevron-left").click()

    page.get_by_text("View 10 row(s)").first.click()

    page.get_by_text("View 20 row(s)").click()

    page.locator(".ng-tns-c457322640-1.ng-star-inserted.col-12.m-t-16 > div > .ng-tns-c457322640-1 > .componentParentWrapper > esp-card-component > .card-container > .card-content > .d-flex.flex-column.row-gap > .d-flex.flex-column.complex-filter > .d-flex.flex-wrap > .font-size-16.d-inline-block > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("div").filter(has_text=re.compile(r"^Latest 4 Next 13$")).nth(1).click()

    page.locator(".ng-tns-c457322640-1.ng-star-inserted.col-12.m-t-16 > div > .ng-tns-c457322640-1 > .componentParentWrapper > esp-card-component > .card-container > .card-content > .d-flex.flex-column.row-gap > .d-flex.flex-column.complex-filter > .d-flex.flex-wrap > .font-size-16.d-inline-block > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.get_by_text("Latest 13 Next").click()

    page.get_by_text("Latest 13 Next").first.click()

    page.locator("div").filter(has_text=re.compile(r"^Latest 52 Next 26$")).first.click()

    page.locator(".ng-tns-c457322640-1.ng-star-inserted.col-12.m-t-16 > div > .ng-tns-c457322640-1 > .componentParentWrapper > esp-card-component > .card-container > .card-content > .d-flex.flex-column.row-gap > .d-flex.flex-column.complex-filter > .d-flex.flex-wrap > .font-size-16.d-inline-block > .wr-20 > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100 > .d-flex.align-items-center > .dropdown-caret").click()

    page.get_by_text("Latest 104 Next").click()

    page.locator(".ellipses > esp-multiselect-dropdown > .multiselect-dropdown > div > .w-100").click()

    page.locator("dp-line-bar-chart").get_by_text("Base Override").click()

    page.locator("dp-line-bar-chart").get_by_text("Promo Override").click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(8)").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").first.click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(9) > .d-flex").click()

    page.get_by_text("Weekly Trend Product:").click()

    page.get_by_text("All selected").first.click()

    page.locator(".d-flex.flex-column.justify-content-center").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(4)").click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(4) > .d-flex").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").first.click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").click()

    page.get_by_text("Demand Plan Forecast/Actual").click()

    page.get_by_text("Demand Plan Forecast/Actual").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.zeb-check").click()

    page.get_by_text("Demand Plan Forecast/Actual").click()

    page.locator(".d-flex.flex-column.justify-content-center").first.click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(2) > .d-flex").click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(3)").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").first.click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(6)").click()

    page.locator(".overflow-auto.scrollbar.max-h-147 > div:nth-child(7) > .d-flex").click()

    page.locator(".d-flex.flex-column.justify-content-center.font-size-10.align-items-center.checkbox-v2.m-r-10.deselected").click()

    page.get_by_text("All selected").first.click()

    page.locator(".title.d-flex.align-items-center.font-size-16.font-weight-bold.nunito.title-color > .grid-icons-container > esp-grid-icons-component > .display-grid-icons > div > div > .legend-font > .multiselect-dropdown > .pointer").click()

    page.get_by_text("Save Preference").click()

    page.locator("svg").get_by_text("Demand Plan").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("AI Total Forecast").click()

    page.locator("svg").get_by_text("Forecast/Actual Demand").click()

    page.locator("svg").get_by_text("AI Total Forecast").click()

    page.locator("svg").get_by_text("Demand Plan").click()

    page.locator("svg").get_by_text("AI Promo Forecast").click()

    page.locator("svg").get_by_text("AI Promo Forecast").click()

    page.locator("svg").get_by_text("YOY % Change").click()

    page.locator("svg").get_by_text("YOY % Change").click()

    page.locator("svg").get_by_text("LY Actual Demand").click()

    page.locator("svg").get_by_text("LY Actual Demand").click()

    page.locator("svg").get_by_text("Base Override").click()

    page.locator("svg").get_by_text("Base Override").click()

    page.locator("svg").get_by_text("Promo Override").click()

    page.locator("svg").get_by_text("Promo Override").click()

    page.locator("svg").get_by_text("AI Base Forecast").click()

    page.locator("svg").get_by_text("AI Base Forecast").click()

    page.locator("svg").click()

    page.locator("path:nth-child(219)").click()

